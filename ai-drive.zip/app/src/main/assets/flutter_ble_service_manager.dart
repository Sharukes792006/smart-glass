// ==============================================================================
// AI DRIVE — ESP32-S3 BLE SERVICE MANAGER (FLUTTER / DART)
// Package: flutter_blue_plus: ^1.34.0 (or latest compatible)
//
// Description:
// Production-grade Bluetooth Low Energy service manager for AI Smart Driver
// Safety Glasses powered by ESP32-S3. Handles scanning, connecting, auto-reconnect,
// MTU negotiation, characteristic discovery, notifications, and strict JSON packet
// parsing according to the AI Drive specification.
// ==============================================================================

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

/// Connection states for the AI Drive Smart Glasses BLE hardware
enum BleConnectionStatus {
  disconnected,
  scanning,
  connecting,
  connected,
  disconnecting,
  error,
}

/// Hardware sensor status decoded from ESP32-S3 telemetry packet
class Esp32GlassesTelemetry {
  final String deviceId;
  final int timestamp;
  final String fatigue; // "LOW", "MEDIUM", "HIGH"
  final String distraction; // "LOW", "MEDIUM", "HIGH"
  final String alcohol; // "UNKNOWN", "NORMAL", "WARNING", "CRITICAL"
  final String headMovement; // "NORMAL", "ABNORMAL", "NODDING"
  final int riskScore; // 0..100
  final String riskLevel; // "SAFE", "WARNING", "CRITICAL"
  final int? rssi;
  final DateTime receivedAt;

  const Esp32GlassesTelemetry({
    required this.deviceId,
    required this.timestamp,
    required this.fatigue,
    required this.distraction,
    required this.alcohol,
    required this.headMovement,
    required this.riskScore,
    required this.riskLevel,
    this.rssi,
    required this.receivedAt,
  });

  /// Factory constructor to validate incoming JSON packet and handle malformed fields safely
  factory Esp32GlassesTelemetry.fromJson(Map<String, dynamic> json, {int? rssi}) {
    return Esp32GlassesTelemetry(
      deviceId: json['deviceId']?.toString() ?? 'AI-DRIVE-001',
      timestamp: (json['timestamp'] is num)
          ? (json['timestamp'] as num).toInt()
          : DateTime.now().millisecondsSinceEpoch ~/ 1000,
      fatigue: (json['fatigue']?.toString() ?? 'LOW').toUpperCase(),
      distraction: (json['distraction']?.toString() ?? 'LOW').toUpperCase(),
      alcohol: (json['alcohol']?.toString() ?? 'UNKNOWN').toUpperCase(),
      headMovement: (json['headMovement']?.toString() ?? 'NORMAL').toUpperCase(),
      riskScore: (json['riskScore'] is num)
          ? (json['riskScore'] as num).toInt().clamp(0, 100)
          : 100,
      riskLevel: (json['riskLevel']?.toString() ?? 'SAFE').toUpperCase(),
      rssi: rssi,
      receivedAt: DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'deviceId': deviceId,
        'timestamp': timestamp,
        'fatigue': fatigue,
        'distraction': distraction,
        'alcohol': alcohol,
        'headMovement': headMovement,
        'riskScore': riskScore,
        'riskLevel': riskLevel,
        'rssi': rssi,
        'receivedAt': receivedAt.toIso8601String(),
      };

  bool get isCritical => riskLevel == 'CRITICAL' || fatigue == 'HIGH';
  bool get isWarning => riskLevel == 'WARNING' || fatigue == 'MEDIUM';
}

/// ESP32-S3 BLE UUID configuration & constants
class GlassesBleConstants {
  /// Default Service UUID configured on ESP32-S3 firmware
  static const String defaultServiceUuid = '12345678-1234-1234-1234-1234567890ab';

  /// Default Characteristic UUID for streaming JSON telemetry
  static const String telemetryCharUuid = '12345678-1234-1234-1234-1234567890ac';

  /// Advertised device name prefix
  static const String deviceNamePrefix = 'AI-DRIVE';

  /// Default target device name
  static const String defaultDeviceName = 'AI-DRIVE-001';

  /// Scan timeout
  static const Duration scanTimeout = Duration(seconds: 12);

  /// Auto-reconnect retry delay
  static const Duration reconnectDelay = Duration(seconds: 5);
}

/// Production Flutter BLE Service Manager using flutter_blue_plus
class FlutterBleGlassesManager {
  // Singleton pattern
  static final FlutterBleGlassesManager _instance = FlutterBleGlassesManager._internal();
  factory FlutterBleGlassesManager() => _instance;
  FlutterBleGlassesManager._internal();

  // Configurable UUIDs
  Guid serviceUuid = Guid(GlassesBleConstants.defaultServiceUuid);
  Guid telemetryCharUuid = Guid(GlassesBleConstants.telemetryCharUuid);

  // Reactive State Streams
  final _connectionStatusController =
      StreamController<BleConnectionStatus>.broadcast();
  Stream<BleConnectionStatus> get connectionStatusStream =>
      _connectionStatusController.stream;
  BleConnectionStatus _currentStatus = BleConnectionStatus.disconnected;
  BleConnectionStatus get currentStatus => _currentStatus;

  final _telemetryController = StreamController<Esp32GlassesTelemetry>.broadcast();
  Stream<Esp32GlassesTelemetry> get telemetryStream => _telemetryController.stream;

  final _discoveredDevicesController =
      StreamController<List<ScanResult>>.broadcast();
  Stream<List<ScanResult>> get discoveredDevicesStream =>
      _discoveredDevicesController.stream;

  final _errorMessageController = StreamController<String>.broadcast();
  Stream<String> get errorMessageStream => _errorMessageController.stream;

  // Active Connection References
  BluetoothDevice? _connectedDevice;
  BluetoothDevice? get connectedDevice => _connectedDevice;

  BluetoothCharacteristic? _telemetryCharacteristic;
  StreamSubscription<List<int>>? _telemetrySubscription;
  StreamSubscription<BluetoothConnectionState>? _deviceConnectionSubscription;
  StreamSubscription<List<ScanResult>>? _scanResultsSubscription;

  bool _isAutoReconnectEnabled = true;
  bool _isDisposed = false;
  int? _lastRssi;

  /// Configure custom UUIDs if ESP32-S3 firmware build differs
  void configureUuids({String? service, String? characteristic}) {
    if (service != null) serviceUuid = Guid(service);
    if (characteristic != null) telemetryCharUuid = Guid(characteristic);
  }

  /// Initialize BLE adapter monitoring
  Future<void> initialize() async {
    // Check if Bluetooth is supported
    if (await FlutterBluePlus.isSupported == false) {
      _notifyError('Bluetooth is not supported on this device');
      _updateStatus(BleConnectionStatus.error);
      return;
    }

    // Monitor adapter state
    FlutterBluePlus.adapterState.listen((BluetoothAdapterState state) {
      if (state == BluetoothAdapterState.on) {
        if (_currentStatus == BleConnectionStatus.error) {
          _updateStatus(BleConnectionStatus.disconnected);
        }
      } else if (state == BluetoothAdapterState.off) {
        _updateStatus(BleConnectionStatus.disconnected);
        _notifyError('Bluetooth was turned off');
      }
    });
  }

  /// Start scanning for AI-DRIVE ESP32-S3 glasses
  Future<void> startScan({Duration timeout = GlassesBleConstants.scanTimeout}) async {
    if (_currentStatus == BleConnectionStatus.scanning ||
        _currentStatus == BleConnectionStatus.connecting) {
      return;
    }

    try {
      // Ensure bluetooth is turned on (Android can request enable)
      if (Platform.isAndroid) {
        await FlutterBluePlus.turnOn().catchError((_) {});
      }

      _updateStatus(BleConnectionStatus.scanning);

      // Cancel previous scan listener
      await _scanResultsSubscription?.cancel();

      // Listen to scan results filtering for AI-DRIVE devices or target Service UUID
      _scanResultsSubscription = FlutterBluePlus.scanResults.listen((results) {
        final filtered = results.where((r) {
          final name = r.device.platformName.toUpperCase();
          final advName = r.advertisementData.advName.toUpperCase();
          final matchesName = name.startsWith(GlassesBleConstants.deviceNamePrefix) ||
              advName.startsWith(GlassesBleConstants.deviceNamePrefix);
          final matchesUuid = r.advertisementData.serviceUuids.contains(serviceUuid);
          return matchesName || matchesUuid;
        }).toList();

        _discoveredDevicesController.add(filtered);
      }, onError: (e) {
        _notifyError('Scan error: $e');
        _updateStatus(BleConnectionStatus.error);
      });

      // Start scan with service filter or general scan
      await FlutterBluePlus.startScan(
        withServices: [serviceUuid], // Scan for AI Drive GATT service
        timeout: timeout,
      );

      // If no devices found with strict service filter, fallback to name-based scan
      FlutterBluePlus.isScanning.listen((isScanning) {
        if (!isScanning && _currentStatus == BleConnectionStatus.scanning) {
          _updateStatus(BleConnectionStatus.disconnected);
        }
      });
    } catch (e) {
      _notifyError('Failed to start BLE scan: $e');
      _updateStatus(BleConnectionStatus.error);
    }
  }

  /// Stop current scan
  Future<void> stopScan() async {
    try {
      await FlutterBluePlus.stopScan();
      if (_currentStatus == BleConnectionStatus.scanning) {
        _updateStatus(BleConnectionStatus.disconnected);
      }
    } catch (e) {
      debugPrint('Error stopping scan: $e');
    }
  }

  /// Connect to ESP32-S3 Glasses device
  Future<bool> connect(BluetoothDevice device, {bool autoReconnect = true}) async {
    await stopScan();
    _isAutoReconnectEnabled = autoReconnect;
    _connectedDevice = device;
    _updateStatus(BleConnectionStatus.connecting);

    try {
      // Listen to hardware connection state changes
      await _deviceConnectionSubscription?.cancel();
      _deviceConnectionSubscription = device.connectionState.listen((state) {
        _handleDeviceConnectionChange(device, state);
      });

      // Connect with timeout and autoConnect disabled for faster connection on Android
      await device.connect(
        timeout: const Duration(seconds: 15),
        autoConnect: false,
      );

      // Android: Request higher MTU (512 bytes) to receive complete JSON packets without chunking
      if (Platform.isAndroid) {
        try {
          await device.requestMtu(512);
        } catch (e) {
          debugPrint('MTU request warning (non-fatal): $e');
        }
      }

      // Discover GATT Services
      final services = await device.discoverServices();
      final targetService = services.firstWhere(
        (s) => s.uuid == serviceUuid,
        orElse: () => throw Exception('Service $serviceUuid not found on ${device.platformName}'),
      );

      // Find Telemetry Characteristic
      final targetChar = targetService.characteristics.firstWhere(
        (c) => c.uuid == telemetryCharUuid,
        orElse: () => throw Exception('Characteristic $telemetryCharUuid not found'),
      );

      _telemetryCharacteristic = targetChar;

      // Subscribe to Notifications
      await _subscribeToTelemetry(targetChar);

      _updateStatus(BleConnectionStatus.connected);
      return true;
    } catch (e) {
      _notifyError('Connection failed: $e');
      _updateStatus(BleConnectionStatus.error);
      await disconnect();
      return false;
    }
  }

  /// Subscribe and parse incoming JSON notifications
  Future<void> _subscribeToTelemetry(BluetoothCharacteristic characteristic) async {
    await _telemetrySubscription?.cancel();

    // Enable notification on characteristic
    await characteristic.setNotifyValue(true);

    // Buffer for chunked packets if MTU was not negotiated
    final StringBuffer packetBuffer = StringBuffer();

    _telemetrySubscription = characteristic.lastValueStream.listen((value) {
      if (value.isEmpty) return;

      try {
        final decodedChunk = utf8.decode(value, allowMalformed: true);
        packetBuffer.write(decodedChunk);

        final accumulated = packetBuffer.toString();

        // Check for complete JSON object boundaries
        if (accumulated.contains('{') && accumulated.contains('}')) {
          final startIdx = accumulated.indexOf('{');
          final endIdx = accumulated.lastIndexOf('}');

          if (endIdx > startIdx) {
            final jsonStr = accumulated.substring(startIdx, endIdx + 1);
            packetBuffer.clear();

            // Retain any remaining trailing characters
            if (endIdx + 1 < accumulated.length) {
              packetBuffer.write(accumulated.substring(endIdx + 1));
            }

            _parseAndEmitPacket(jsonStr);
          }
        }
      } catch (e) {
        debugPrint('Raw packet decoding error: $e');
      }
    }, onError: (e) {
      _notifyError('Telemetry stream error: $e');
    });
  }

  /// Parse and validate JSON packet
  void _parseAndEmitPacket(String jsonString) {
    try {
      final dynamic parsed = jsonDecode(jsonString);
      if (parsed is Map<String, dynamic>) {
        final telemetry = Esp32GlassesTelemetry.fromJson(parsed, rssi: _lastRssi);
        _telemetryController.add(telemetry);
      } else {
        debugPrint('Ignored non-map JSON telemetry payload');
      }
    } catch (e) {
      debugPrint('Malformed telemetry JSON packet: $jsonString ($e)');
    }
  }

  /// Handle device connection changes (disconnection & auto-reconnect)
  void _handleDeviceConnectionChange(BluetoothDevice device, BluetoothConnectionState state) {
    switch (state) {
      case BluetoothConnectionState.connected:
        _updateStatus(BleConnectionStatus.connected);
        break;
      case BluetoothConnectionState.disconnected:
        _updateStatus(BleConnectionStatus.disconnected);
        if (_isAutoReconnectEnabled && !_isDisposed) {
          debugPrint('Device disconnected. Attempting auto-reconnect in 5s...');
          Timer(GlassesBleConstants.reconnectDelay, () {
            if (_isAutoReconnectEnabled &&
                _connectedDevice != null &&
                _currentStatus == BleConnectionStatus.disconnected) {
              connect(_connectedDevice!, autoReconnect: true);
            }
          });
        }
        break;
      default:
        break;
    }
  }

  /// Disconnect from ESP32-S3 Glasses
  Future<void> disconnect() async {
    _isAutoReconnectEnabled = false;
    _updateStatus(BleConnectionStatus.disconnecting);

    try {
      await _telemetrySubscription?.cancel();
      _telemetrySubscription = null;

      if (_telemetryCharacteristic != null) {
        try {
          await _telemetryCharacteristic?.setNotifyValue(false);
        } catch (_) {}
        _telemetryCharacteristic = null;
      }

      await _deviceConnectionSubscription?.cancel();
      _deviceConnectionSubscription = null;

      if (_connectedDevice != null) {
        await _connectedDevice?.disconnect();
        _connectedDevice = null;
      }

      _updateStatus(BleConnectionStatus.disconnected);
    } catch (e) {
      _notifyError('Error during disconnect: $e');
      _updateStatus(BleConnectionStatus.error);
    }
  }

  void _updateStatus(BleConnectionStatus status) {
    _currentStatus = status;
    if (!_connectionStatusController.isClosed) {
      _connectionStatusController.add(status);
    }
  }

  void _notifyError(String message) {
    debugPrint('[FlutterBleGlassesManager] $message');
    if (!_errorMessageController.isClosed) {
      _errorMessageController.add(message);
    }
  }

  /// Clean up streams and active connections
  void dispose() {
    _isDisposed = true;
    _isAutoReconnectEnabled = false;
    disconnect();
    _connectionStatusController.close();
    _telemetryController.close();
    _discoveredDevicesController.close();
    _errorMessageController.close();
  }
}
