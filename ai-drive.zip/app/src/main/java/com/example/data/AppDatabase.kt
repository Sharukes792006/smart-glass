package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.models.EmergencyContact
import com.example.models.SafetyAlert
import com.example.models.SosEvent
import com.example.models.Trip
import kotlinx.coroutines.flow.Flow

@Dao
interface AlertDao {
    @Query("SELECT * FROM safety_alerts ORDER BY timestamp DESC")
    fun getAllAlerts(): Flow<List<SafetyAlert>>

    @Query("SELECT * FROM safety_alerts WHERE acknowledged = 0 ORDER BY timestamp DESC")
    fun getUnacknowledgedAlerts(): Flow<List<SafetyAlert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: SafetyAlert)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<SafetyAlert>)

    @Query("UPDATE safety_alerts SET acknowledged = 1 WHERE id = :alertId")
    suspend fun acknowledgeAlert(alertId: String)

    @Query("UPDATE safety_alerts SET acknowledged = 1")
    suspend fun acknowledgeAll()

    @Query("DELETE FROM safety_alerts")
    suspend fun clearAll()
}

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY startTime DESC")
    fun getAllTrips(): Flow<List<Trip>>

    @Query("SELECT * FROM trips WHERE id = :tripId LIMIT 1")
    suspend fun getTripById(tripId: String): Trip?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: Trip)

    @Update
    suspend fun updateTrip(trip: Trip)

    @Query("DELETE FROM trips WHERE id = :tripId")
    suspend fun deleteTrip(tripId: String)
}

@Dao
interface ContactDao {
    @Query("SELECT * FROM emergency_contacts ORDER BY isPrimary DESC, name ASC")
    fun getAllContacts(): Flow<List<EmergencyContact>>

    @Query("SELECT * FROM emergency_contacts WHERE isPrimary = 1 LIMIT 1")
    suspend fun getPrimaryContact(): EmergencyContact?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: EmergencyContact)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContacts(contacts: List<EmergencyContact>)

    @Query("DELETE FROM emergency_contacts WHERE id = :contactId")
    suspend fun deleteContact(contactId: String)
}

@Dao
interface SosDao {
    @Query("SELECT * FROM sos_events ORDER BY timestamp DESC")
    fun getAllEvents(): Flow<List<SosEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: SosEvent)

    @Query("UPDATE sos_events SET status = :status WHERE id = :eventId")
    suspend fun updateStatus(eventId: String, status: com.example.models.SosStatus)
}

@Database(
    entities = [SafetyAlert::class, Trip::class, EmergencyContact::class, SosEvent::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun alertDao(): AlertDao
    abstract fun tripDao(): TripDao
    abstract fun contactDao(): ContactDao
    abstract fun sosDao(): SosDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ai_drive_safety.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
