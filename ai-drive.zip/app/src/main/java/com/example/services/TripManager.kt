package com.example.services

import com.example.data.AppDatabase
import com.example.models.SafetyScore
import com.example.models.Trip
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

data class ActiveTripState(
    val isRunning: Boolean = false,
    val tripId: String? = null,
    val startTimeMs: Long = 0L,
    val durationSeconds: Long = 0L,
    val distanceKm: Float = 0f,
    val currentSpeedKmh: Float = 0f,
    val averageScore: Int = 98,
    val fatigueCount: Int = 0,
    val distractionCount: Int = 0,
    val alcoholCount: Int = 0
)

class TripManager(
    private val database: AppDatabase,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private var tripTickerJob: Job? = null
    private val _activeTrip = MutableStateFlow(ActiveTripState())
    val activeTrip: StateFlow<ActiveTripState> = _activeTrip.asStateFlow()

    private val scoreSamples = mutableListOf<Int>()

    fun startTrip(isSimulated: Boolean = true) {
        val tripId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        scoreSamples.clear()
        scoreSamples.add(98)

        _activeTrip.value = ActiveTripState(
            isRunning = true,
            tripId = tripId,
            startTimeMs = now,
            durationSeconds = 0L,
            distanceKm = 0f,
            currentSpeedKmh = 45f,
            averageScore = 98,
            fatigueCount = 0,
            distractionCount = 0,
            alcoholCount = 0
        )

        tripTickerJob?.cancel()
        tripTickerJob = scope.launch {
            val liveTrip = Trip(
                id = tripId,
                startTime = now,
                isLive = true,
                isSimulated = isSimulated,
                originSummary = "San Francisco Downtown HUD",
                destinationSummary = "Silicon Valley Highway 101"
            )
            database.tripDao().insertTrip(liveTrip)

            while (isActive) {
                delay(1000L)
                if (_activeTrip.value.isRunning) {
                    val current = _activeTrip.value
                    val newDuration = current.durationSeconds + 1
                    // Simulated distance accumulation at ~60 km/h avg
                    val deltaKm = (55f + kotlin.random.Random.nextFloat() * 15f) / 3600f
                    val newDist = current.distanceKm + deltaKm
                    val currentSpeed = 50f + kotlin.random.Random.nextFloat() * 20f

                    val avgScore = if (scoreSamples.isNotEmpty()) {
                        scoreSamples.average().toInt()
                    } else 95

                    _activeTrip.value = current.copy(
                        durationSeconds = newDuration,
                        distanceKm = newDist,
                        currentSpeedKmh = currentSpeed,
                        averageScore = avgScore
                    )
                }
            }
        }
    }

    fun recordSafetyEvaluation(score: SafetyScore) {
        if (!_activeTrip.value.isRunning) return
        scoreSamples.add(score.score)
        val current = _activeTrip.value
        val fatigueInc = if (score.fatiguePenalty > 0) 1 else 0
        val distInc = if (score.distractionPenalty > 0) 1 else 0
        val alcInc = if (score.alcoholPenalty > 0) 1 else 0

        _activeTrip.value = current.copy(
            fatigueCount = current.fatigueCount + fatigueInc,
            distractionCount = current.distractionCount + distInc,
            alcoholCount = current.alcoholCount + alcInc
        )
    }

    fun stopTrip() {
        val current = _activeTrip.value
        if (!current.isRunning || current.tripId == null) return

        tripTickerJob?.cancel()
        tripTickerJob = null

        val tripId = current.tripId
        val now = System.currentTimeMillis()

        scope.launch {
            val completedTrip = Trip(
                id = tripId,
                startTime = current.startTimeMs,
                endTime = now,
                durationSeconds = current.durationSeconds,
                distanceKm = (current.distanceKm * 10f).toInt() / 10f,
                averageSpeedKmh = if (current.durationSeconds > 0) (current.distanceKm / (current.durationSeconds / 3600f)) else 0f,
                safetyScore = current.averageScore,
                fatigueEventsCount = current.fatigueCount,
                distractionEventsCount = current.distractionCount,
                alcoholAnomaliesCount = current.alcoholCount,
                isLive = false,
                isSimulated = true,
                originSummary = "SF Downtown",
                destinationSummary = "Palo Alto Campus"
            )
            database.tripDao().updateTrip(completedTrip)
        }

        _activeTrip.value = ActiveTripState(isRunning = false)
    }
}
