package com.example.services

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.example.data.AppDatabase
import com.example.models.ActionDeliveryStatus
import com.example.models.ContactEmergencyProgress
import com.example.models.EmergencyConfig
import com.example.models.EmergencyContact
import com.example.models.SosEvent
import com.example.models.SosStatus
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

sealed class SosUiState {
    object Idle : SosUiState()
    data class CountingDown(val secondsRemaining: Int, val reason: String = "Critical Driver Fatigue Alert") : SosUiState()
    data class Executing(
        val event: SosEvent,
        val contacts: List<EmergencyContact>,
        val progressList: List<ContactEmergencyProgress>,
        val isTestMode: Boolean,
        val locationUrl: String
    ) : SosUiState()
    data class Prepared(
        val event: SosEvent,
        val contacts: List<EmergencyContact>,
        val progressList: List<ContactEmergencyProgress>,
        val isTestMode: Boolean
    ) : SosUiState()
    data class Cancelled(val reason: String) : SosUiState()
    data class Completed(
        val event: SosEvent,
        val progressList: List<ContactEmergencyProgress>,
        val summary: String
    ) : SosUiState()
    data class Error(val message: String) : SosUiState()
}

class EmergencySosService(
    private val context: Context,
    private val database: AppDatabase,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main)
) {
    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
    private var countdownJob: Job? = null
    private var lastSosTimestamp = 0L
    private val SOS_COOLDOWN_MS = 15_000L // 15-second debounce against accidental spam

    private val _emergencyConfig = MutableStateFlow(
        EmergencyConfig(
            autoAssistanceEnabled = false,
            userConsentGranted = false,
            countdownDurationSeconds = 10,
            includeGpsLocation = true,
            isTestSimulationMode = true // Safe default
        )
    )
    val emergencyConfig: StateFlow<EmergencyConfig> = _emergencyConfig.asStateFlow()

    private val _sosState = MutableStateFlow<SosUiState>(SosUiState.Idle)
    val sosState: StateFlow<SosUiState> = _sosState.asStateFlow()

    private val _progressList = MutableStateFlow<List<ContactEmergencyProgress>>(emptyList())
    val progressList: StateFlow<List<ContactEmergencyProgress>> = _progressList.asStateFlow()

    fun updateConfig(config: EmergencyConfig) {
        _emergencyConfig.value = config
    }

    fun hasSendSmsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
    }

    fun hasCallPhonePermission(): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
    }

    fun hasGpsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    fun triggerCountdown(
        reason: String = "Manual SOS Triggered",
        overrideSeconds: Int? = null,
        initialSeconds: Int? = null
    ) {
        val now = System.currentTimeMillis()
        if (now - lastSosTimestamp < SOS_COOLDOWN_MS) {
            val cooldownRemaining = ((SOS_COOLDOWN_MS - (now - lastSosTimestamp)) / 1000).toInt()
            _sosState.value = SosUiState.Error("Cooldown active. Please wait $cooldownRemaining seconds before re-triggering.")
            return
        }

        val seconds = overrideSeconds ?: initialSeconds ?: _emergencyConfig.value.countdownDurationSeconds

        countdownJob?.cancel()
        countdownJob = scope.launch {
            vibrateAlert()
            for (sec in seconds downTo 1) {
                _sosState.value = SosUiState.CountingDown(sec, reason)
                delay(1000L)
            }
            // Countdown finished -> execute assistance workflow
            executeEmergencyWorkflow(reason)
        }
    }

    fun cancelCountdown(reason: String = "Cancelled by driver") {
        countdownJob?.cancel()
        countdownJob = null
        _sosState.value = SosUiState.Cancelled(reason)
        scope.launch {
            delay(2500)
            if (_sosState.value is SosUiState.Cancelled) {
                _sosState.value = SosUiState.Idle
            }
        }
    }

    fun triggerImmediateSos(reason: String = "Immediate Manual Panic") {
        val now = System.currentTimeMillis()
        if (now - lastSosTimestamp < SOS_COOLDOWN_MS) {
            val cooldownRemaining = ((SOS_COOLDOWN_MS - (now - lastSosTimestamp)) / 1000).toInt()
            _sosState.value = SosUiState.Error("Cooldown active ($cooldownRemaining seconds remaining).")
            return
        }
        countdownJob?.cancel()
        scope.launch {
            executeEmergencyWorkflow(reason)
        }
    }

    /**
     * Executes the emergency assistance sequence:
     * 1. Fetches GPS coordinates
     * 2. Retrieves configured emergency contacts
     * 3. Either executes direct SMS/Calls or operates in Test Simulation Mode without real actions
     */
    private suspend fun executeEmergencyWorkflow(reason: String) {
        lastSosTimestamp = System.currentTimeMillis()
        val location = if (_emergencyConfig.value.includeGpsLocation) fetchLastLocation() else null
        val contacts = database.contactDao().getPrimaryContact()?.let { listOf(it) }
            ?: listOf(
                EmergencyContact(
                    id = "default_dispatch",
                    name = "Emergency Contact (Family/Dispatch)",
                    phone = "911",
                    relationship = "Primary Responder",
                    isPrimary = true
                )
            )

        val lat = location?.latitude
        val lng = location?.longitude
        val locationUrl = if (lat != null && lng != null) {
            "https://maps.google.com/?q=$lat,$lng"
        } else {
            "Location unavailable"
        }

        val formattedMessage = buildString {
            append(_emergencyConfig.value.smsTemplate.trim())
            append(" Reason: $reason.")
            if (lat != null && lng != null) {
                append(" Live GPS: $locationUrl (Lat: ${"%.4f".format(lat)}, Lng: ${"%.4f".format(lng)}).")
            }
        }

        val event = SosEvent(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            status = SosStatus.PREPARED,
            latitude = lat,
            longitude = lng,
            targetPhone = contacts.first().phone,
            messageContent = formattedMessage,
            notes = "Automated assistance workflow invoked"
        )
        database.sosDao().insertEvent(event)

        val initialProgress = contacts.map { contact ->
            ContactEmergencyProgress(
                contact = contact,
                smsStatus = ActionDeliveryStatus.PENDING,
                callStatus = ActionDeliveryStatus.PENDING
            )
        }
        _progressList.value = initialProgress

        val isTestMode = _emergencyConfig.value.isTestSimulationMode

        _sosState.value = SosUiState.Executing(
            event = event,
            contacts = contacts,
            progressList = initialProgress,
            isTestMode = isTestMode,
            locationUrl = locationUrl
        )

        // Process each contact in sequence
        val updatedProgress = initialProgress.toMutableList()
        for (i in contacts.indices) {
            val contact = contacts[i]

            // 1. Process SMS
            val smsResult = if (isTestMode) {
                delay(800)
                ActionDeliveryStatus.SIMULATED_SUCCESS
            } else {
                sendDirectSmsOrFallback(contact.phone, formattedMessage)
            }

            // 2. Process Call
            val callResult = if (isTestMode) {
                delay(800)
                ActionDeliveryStatus.SIMULATED_SUCCESS
            } else {
                initiateDirectCallOrFallback(contact.phone)
            }

            updatedProgress[i] = updatedProgress[i].copy(
                smsStatus = smsResult,
                callStatus = callResult
            )
            _progressList.value = updatedProgress.toList()
        }

        val finalStatus = if (isTestMode) SosStatus.CONFIRMED else SosStatus.DISPATCHED
        database.sosDao().updateStatus(event.id, finalStatus)

        _sosState.value = SosUiState.Completed(
            event = event.copy(status = finalStatus),
            progressList = updatedProgress,
            summary = if (isTestMode) "Test simulation completed without transmitting real SMS or calls."
            else "Emergency sequence initiated for all configured contacts."
        )
    }

    private fun sendDirectSmsOrFallback(phoneNumber: String, message: String): ActionDeliveryStatus {
        if (!hasSendSmsPermission()) {
            openSmsComposer(phoneNumber, message)
            return ActionDeliveryStatus.FALLBACK_COMPOSER
        }

        return try {
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }

            val parts = smsManager.divideMessage(message)
            if (parts.size > 1) {
                smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)
            } else {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            }
            ActionDeliveryStatus.SENT_DIRECT
        } catch (_: Exception) {
            openSmsComposer(phoneNumber, message)
            ActionDeliveryStatus.FALLBACK_COMPOSER
        }
    }

    private fun initiateDirectCallOrFallback(phoneNumber: String): ActionDeliveryStatus {
        if (!hasCallPhonePermission()) {
            openDialer(phoneNumber)
            return ActionDeliveryStatus.FALLBACK_DIALER
        }

        return try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:${phoneNumber.trim()}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionDeliveryStatus.INITIATED_CALL
        } catch (_: Exception) {
            openDialer(phoneNumber)
            ActionDeliveryStatus.FALLBACK_DIALER
        }
    }

    fun openDialer(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${phoneNumber.trim()}")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) { }
    }

    fun openSmsComposer(phoneNumber: String, message: String, eventId: String? = null) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${phoneNumber.trim()}")
            putExtra("sms_body", message)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) { }
    }

    fun dismissState() {
        _sosState.value = SosUiState.Idle
    }

    @SuppressLint("MissingPermission")
    private suspend fun fetchLastLocation(): Location? {
        return try {
            fusedLocationClient.lastLocation.await()
        } catch (_: Exception) {
            null
        }
    }

    private fun vibrateAlert() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(400)
            }
        } catch (_: Exception) { }
    }
}
