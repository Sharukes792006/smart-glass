package com.example.services.camera

import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors

enum class CameraFacing {
    FRONT,
    BACK
}

class CameraDmsManager(
    private val context: Context,
    val analyzer: DriverFatigueAnalyzer = DriverFatigueAnalyzer()
) {
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    private val _isCameraActive = MutableStateFlow(false)
    val isCameraActive: StateFlow<Boolean> = _isCameraActive.asStateFlow()

    private val _currentLensFacing = MutableStateFlow(CameraFacing.FRONT)
    val currentLensFacing: StateFlow<CameraFacing> = _currentLensFacing.asStateFlow()

    private val _cameraError = MutableStateFlow<String?>(null)
    val cameraError: StateFlow<String?> = _cameraError.asStateFlow()

    private var cameraProvider: ProcessCameraProvider? = null

    fun bindCameraToLifecycle(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView
    ) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        cameraProviderFuture.addListener({
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider
                provider.unbindAll()

                val lensFacing = if (_currentLensFacing.value == CameraFacing.FRONT) {
                    CameraSelector.LENS_FACING_FRONT
                } else {
                    CameraSelector.LENS_FACING_BACK
                }

                val cameraSelector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor, analyzer)
                    }

                provider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageAnalysis
                )

                _isCameraActive.value = true
                _cameraError.value = null
            } catch (e: Exception) {
                // If front camera is not found (e.g. some emulators), fallback to back camera
                if (_currentLensFacing.value == CameraFacing.FRONT) {
                    _currentLensFacing.value = CameraFacing.BACK
                    bindCameraToLifecycle(lifecycleOwner, previewView)
                } else {
                    _isCameraActive.value = false
                    _cameraError.value = "Camera binding failed: ${e.localizedMessage}"
                }
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun toggleCameraFacing(lifecycleOwner: LifecycleOwner, previewView: PreviewView) {
        _currentLensFacing.value = if (_currentLensFacing.value == CameraFacing.FRONT) {
            CameraFacing.BACK
        } else {
            CameraFacing.FRONT
        }
        bindCameraToLifecycle(lifecycleOwner, previewView)
    }

    fun unbindCamera() {
        cameraProvider?.unbindAll()
        _isCameraActive.value = false
    }

    fun release() {
        unbindCamera()
        cameraExecutor.shutdown()
    }
}
