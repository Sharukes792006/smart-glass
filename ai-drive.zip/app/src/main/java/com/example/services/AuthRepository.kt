package com.example.services

import android.content.Context
import android.content.SharedPreferences
import com.example.models.DriverProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    data class Authenticated(val profile: DriverProfile) : AuthState()
    data class Error(val message: String, val canFallbackToDemo: Boolean = true) : AuthState()
}

class AuthRepository(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ai_drive_auth_prefs", Context.MODE_PRIVATE)

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    init {
        checkPersistedSession()
    }

    private fun checkPersistedSession() {
        val isLoggedIn = prefs.getBoolean("is_logged_in", false)
        if (isLoggedIn) {
            val email = prefs.getString("user_email", "driver@aidrive.ai") ?: "driver@aidrive.ai"
            val name = prefs.getString("user_name", "Captain Alex Vance") ?: "Captain Alex Vance"
            val vehicle = prefs.getString("user_vehicle", "Tesla Model 3 Performance") ?: "Tesla Model 3 Performance"
            val blood = prefs.getString("user_blood", "O+") ?: "O+"
            val license = prefs.getString("user_license", "DL-8820-SAFE") ?: "DL-8820-SAFE"
            val isDemo = prefs.getBoolean("is_demo", true)

            _authState.value = AuthState.Authenticated(
                DriverProfile(
                    uid = prefs.getString("user_uid", "demo-user-1") ?: "demo-user-1",
                    fullName = name,
                    email = email,
                    vehicleModel = vehicle,
                    bloodGroup = blood,
                    driverLicense = license,
                    isDemoAccount = isDemo
                )
            )
        } else {
            _authState.value = AuthState.Idle
        }
    }

    suspend fun loginWithEmail(email: String, pass: String): Result<DriverProfile> {
        _authState.value = AuthState.Loading
        kotlinx.coroutines.delay(400) // Simulated auth handshake
        if (!email.contains("@") || email.length < 5) {
            val err = "Please enter a valid email address."
            _authState.value = AuthState.Error(err)
            return Result.failure(IllegalArgumentException(err))
        }
        if (pass.length < 6) {
            val err = "Password must be at least 6 characters long."
            _authState.value = AuthState.Error(err)
            return Result.failure(IllegalArgumentException(err))
        }

        val profile = DriverProfile(
            uid = "user-${email.hashCode()}",
            fullName = email.substringBefore("@").replaceFirstChar { it.uppercase() },
            email = email,
            vehicleModel = "Tesla Model 3 / CyberTruck",
            isDemoAccount = false
        )
        persistProfile(profile)
        _authState.value = AuthState.Authenticated(profile)
        return Result.success(profile)
    }

    suspend fun registerWithEmail(
        name: String,
        email: String,
        pass: String,
        vehicle: String
    ): Result<DriverProfile> {
        _authState.value = AuthState.Loading
        kotlinx.coroutines.delay(500)
        if (name.isBlank() || !email.contains("@") || pass.length < 6) {
            val err = "Please provide complete registration details (password min 6 chars)."
            _authState.value = AuthState.Error(err)
            return Result.failure(IllegalArgumentException(err))
        }

        val profile = DriverProfile(
            uid = "user-${System.currentTimeMillis()}",
            fullName = name.trim(),
            email = email.trim(),
            vehicleModel = if (vehicle.isNotBlank()) vehicle.trim() else "Smart Electric Vehicle",
            isDemoAccount = false
        )
        persistProfile(profile)
        _authState.value = AuthState.Authenticated(profile)
        return Result.success(profile)
    }

    fun startDemoSession(): DriverProfile {
        val demoProfile = DriverProfile(
            uid = "demo-driver-001",
            fullName = "Pilot Morgan Reese",
            email = "demo.driver@aidrive.system",
            vehicleModel = "Porsche Taycan 4S / Pilot HUD",
            bloodGroup = "A+",
            driverLicense = "DEMO-PERMIT-404",
            isDemoAccount = true
        )
        persistProfile(demoProfile)
        _authState.value = AuthState.Authenticated(demoProfile)
        return demoProfile
    }

    suspend fun sendPasswordReset(email: String): Result<String> {
        kotlinx.coroutines.delay(300)
        if (!email.contains("@")) {
            return Result.failure(IllegalArgumentException("Invalid email format"))
        }
        return Result.success("Password reset instructions sent to $email")
    }

    fun updateProfile(profile: DriverProfile) {
        persistProfile(profile)
        _authState.value = AuthState.Authenticated(profile)
    }

    fun logout() {
        prefs.edit().clear().apply()
        _authState.value = AuthState.Idle
    }

    private fun persistProfile(profile: DriverProfile) {
        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_uid", profile.uid)
            .putString("user_name", profile.fullName)
            .putString("user_email", profile.email)
            .putString("user_vehicle", profile.vehicleModel)
            .putString("user_blood", profile.bloodGroup)
            .putString("user_license", profile.driverLicense)
            .putBoolean("is_demo", profile.isDemoAccount)
            .apply()
    }
}
