package com.example.services

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.models.AlertCategory
import com.example.models.AlertSeverity
import com.example.models.BleConnectionState
import com.example.models.BleGlassesState
import com.example.models.DataSource
import com.example.models.EmergencyContact
import com.example.models.SafetyAlert
import com.example.models.SafetyScore
import com.example.models.SafetyStatus
import com.example.models.SimulationScenario
import com.example.models.TelemetryData
import com.example.models.Trip
import com.example.services.camera.CameraDmsManager
import com.example.services.camera.DriverFatigueAnalyzer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val database = AppDatabase.getInstance(application)
    val authRepository = AuthRepository(application)
    val simulationEngine = SimulationEngine(viewModelScope)
    val bleGlassesManager = BleGlassesManager(application)
    val emergencySosService = EmergencySosService(application, database, viewModelScope)
    val tripManager = TripManager(database, viewModelScope)

    // Auth
    val authState = authRepository.authState

    // Simulation
    val simState = simulationEngine.simState
    val activeScenario = simulationEngine.activeScenario

    // BLE Hardware State
    val bleGlassesState: StateFlow<BleGlassesState> = bleGlassesManager.glassesState

    // CameraX Driver Fatigue DMS
    private val _isCameraModeActive = MutableStateFlow(false)
    val isCameraModeActive: StateFlow<Boolean> = _isCameraModeActive.asStateFlow()

    val cameraDmsManager = CameraDmsManager(
        application,
        DriverFatigueAnalyzer { cameraTelemetry ->
            if (_isCameraModeActive.value) {
                _liveTelemetry.value = cameraTelemetry
                processTelemetry(cameraTelemetry)
            }
        }
    )

    // Live Telemetry Stream (Driven by either Simulation or CameraX DMS)
    private val _liveTelemetry = MutableStateFlow(TelemetryData())
    val liveTelemetry: StateFlow<TelemetryData> = _liveTelemetry.asStateFlow()

    // Safety Score
    private val _safetyScore = MutableStateFlow(SafetyScore(score = 98, status = SafetyStatus.OPTIMAL))
    val safetyScore: StateFlow<SafetyScore> = _safetyScore.asStateFlow()

    // Alert Flow from Room
    val alertsList: StateFlow<List<SafetyAlert>> = database.alertDao().getAllAlerts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Trips Flow from Room
    val tripsList: StateFlow<List<Trip>> = database.tripDao().getAllTrips()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Emergency Contacts Flow from Room
    val contactsList: StateFlow<List<EmergencyContact>> = database.contactDao().getAllContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Trip State
    val activeTrip = tripManager.activeTrip

    // SOS State
    val sosUiState = emergencySosService.sosState

    // Selected Alert Filter
    private val _selectedAlertFilter = MutableStateFlow<AlertCategory?>(null)
    val selectedAlertFilter: StateFlow<AlertCategory?> = _selectedAlertFilter.asStateFlow()

    private var lastAlertEmissionMs = 0L

    init {
        seedDemoDataIfNeeded()
        observeTelemetryForSafety()
        // Connect physical BLE callback if real device sends packet
        bleGlassesManager.onPhysicalTelemetryReceived = { physicalTelemetry ->
            processTelemetry(physicalTelemetry)
        }
    }

    private fun observeTelemetryForSafety() {
        viewModelScope.launch {
            simulationEngine.telemetry.collect { simTelemetry ->
                if (!_isCameraModeActive.value) {
                    _liveTelemetry.value = simTelemetry
                    processTelemetry(simTelemetry)
                }
            }
        }
    }

    fun setCameraModeActive(active: Boolean) {
        _isCameraModeActive.value = active
        if (!active) {
            _liveTelemetry.value = simulationEngine.telemetry.value
            processTelemetry(simulationEngine.telemetry.value)
        }
    }

    override fun onCleared() {
        super.onCleared()
        cameraDmsManager.release()
    }

    private fun processTelemetry(telemetry: TelemetryData) {
        val score = SafetyEvaluationEngine.calculateSafetyScore(telemetry)
        _safetyScore.value = score
        tripManager.recordSafetyEvaluation(score)

        // Evaluate alerts with 4-second throttle to prevent DB floods
        val now = System.currentTimeMillis()
        if (now - lastAlertEmissionMs > 4000L) {
            val potentialAlert = SafetyEvaluationEngine.detectAlert(telemetry)
            if (potentialAlert != null) {
                lastAlertEmissionMs = now
                viewModelScope.launch {
                    database.alertDao().insertAlert(potentialAlert)
                }
            }
        }
    }

    fun startSimulation(scenario: SimulationScenario) {
        simulationEngine.start(scenario)
    }

    fun pauseSimulation() {
        simulationEngine.pause()
    }

    fun resumeSimulation() {
        simulationEngine.resume()
    }

    fun stopSimulation() {
        simulationEngine.stop()
    }

    fun setScenario(scenario: SimulationScenario) {
        simulationEngine.switchScenario(scenario)
    }

    fun acknowledgeAlert(alertId: String) {
        viewModelScope.launch {
            database.alertDao().acknowledgeAlert(alertId)
        }
    }

    fun acknowledgeAllAlerts() {
        viewModelScope.launch {
            database.alertDao().acknowledgeAll()
        }
    }

    fun setAlertFilter(category: AlertCategory?) {
        _selectedAlertFilter.value = category
    }

    fun startTrip() {
        tripManager.startTrip(isSimulated = true)
        if (simState.value == SimulationState.STOPPED) {
            simulationEngine.start(activeScenario.value)
        }
    }

    fun stopTrip() {
        tripManager.stopTrip()
    }

    fun triggerSosCountdown() {
        emergencySosService.triggerCountdown(initialSeconds = 5)
    }

    fun triggerImmediateSos() {
        emergencySosService.triggerImmediateSos()
    }

    fun cancelSos() {
        emergencySosService.cancelCountdown()
    }

    fun dismissSosDialog() {
        emergencySosService.dismissState()
    }

    fun startBleScan() {
        bleGlassesManager.startScan()
    }

    fun stopBleScan() {
        bleGlassesManager.stopScan()
    }

    fun disconnectBle() {
        bleGlassesManager.disconnect()
    }

    fun addEmergencyContact(name: String, phone: String, relationship: String, isPrimary: Boolean) {
        viewModelScope.launch {
            val contact = EmergencyContact(
                id = UUID.randomUUID().toString(),
                name = name.trim(),
                phone = phone.trim(),
                relationship = relationship.trim(),
                isPrimary = isPrimary
            )
            database.contactDao().insertContact(contact)
        }
    }

    fun deleteEmergencyContact(contactId: String) {
        viewModelScope.launch {
            database.contactDao().deleteContact(contactId)
        }
    }

    private fun seedDemoDataIfNeeded() {
        viewModelScope.launch {
            val existingContacts = database.contactDao().getPrimaryContact()
            if (existingContacts == null) {
                database.contactDao().insertContacts(
                    listOf(
                        EmergencyContact(
                            id = "contact_1",
                            name = "Sarah Vance",
                            phone = "+1 (415) 555-0192",
                            relationship = "Spouse",
                            isPrimary = true
                        ),
                        EmergencyContact(
                            id = "contact_2",
                            name = "Dr. Marcus Reed",
                            phone = "+1 (650) 555-0148",
                            relationship = "Emergency Physician",
                            isPrimary = false
                        )
                    )
                )

                // Seed initial realistic demo trips
                val now = System.currentTimeMillis()
                database.tripDao().insertTrip(
                    Trip(
                        id = "trip_demo_1",
                        startTime = now - 3600_000 * 24,
                        endTime = now - 3600_000 * 23 + 1800_000,
                        durationSeconds = 2700L,
                        distanceKm = 42.4f,
                        averageSpeedKmh = 56.5f,
                        safetyScore = 96,
                        fatigueEventsCount = 0,
                        distractionEventsCount = 1,
                        alcoholAnomaliesCount = 0,
                        isLive = false,
                        isSimulated = true,
                        originSummary = "San Francisco Downtown",
                        destinationSummary = "San Jose Tech Park"
                    )
                )
                database.tripDao().insertTrip(
                    Trip(
                        id = "trip_demo_2",
                        startTime = now - 3600_000 * 48,
                        endTime = now - 3600_000 * 46,
                        durationSeconds = 7200L,
                        distanceKm = 118.0f,
                        averageSpeedKmh = 59.0f,
                        safetyScore = 88,
                        fatigueEventsCount = 2,
                        distractionEventsCount = 3,
                        alcoholAnomaliesCount = 0,
                        isLive = false,
                        isSimulated = true,
                        originSummary = "Oakland Airport",
                        destinationSummary = "Monterey Coastal Highway"
                    )
                )

                // Seed initial alerts for demo preview
                database.alertDao().insertAlerts(
                    listOf(
                        SafetyAlert(
                            id = "alert_seed_1",
                            title = "Eye Gaze Off-Road Warning",
                            message = "Driver glance diverted from primary driving vector for 2.8s near highway interchange.",
                            category = AlertCategory.DISTRACTION,
                            severity = AlertSeverity.WARNING,
                            timestamp = now - 3600_000 * 23,
                            acknowledged = true,
                            isDemo = true
                        ),
                        SafetyAlert(
                            id = "alert_seed_2",
                            title = "Rest Break Advisory",
                            message = "Consecutive driving exceeded 90 minutes. Blink rate slowed by 15%.",
                            category = AlertCategory.FATIGUE,
                            severity = AlertSeverity.INFO,
                            timestamp = now - 3600_000 * 47,
                            acknowledged = false,
                            isDemo = true
                        )
                    )
                )
            }
        }
    }
}
