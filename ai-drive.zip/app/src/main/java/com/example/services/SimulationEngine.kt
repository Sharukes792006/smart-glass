package com.example.services

import com.example.models.AlcoholState
import com.example.models.DataSource
import com.example.models.DistractionType
import com.example.models.DrowsinessLevel
import com.example.models.SimulationScenario
import com.example.models.TelemetryData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class SimulationState {
    STOPPED,
    RUNNING,
    PAUSED
}

class SimulationEngine(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private var job: Job? = null

    private val _simState = MutableStateFlow(SimulationState.STOPPED)
    val simState: StateFlow<SimulationState> = _simState.asStateFlow()

    private val _activeScenario = MutableStateFlow(SimulationScenario.NORMAL_DRIVING)
    val activeScenario: StateFlow<SimulationScenario> = _activeScenario.asStateFlow()

    private val _telemetry = MutableStateFlow(createBaselineTelemetry())
    val telemetry: StateFlow<TelemetryData> = _telemetry.asStateFlow()

    private var tickCount = 0

    fun start(scenario: SimulationScenario = _activeScenario.value) {
        _activeScenario.value = scenario
        _simState.value = SimulationState.RUNNING
        job?.cancel()
        job = scope.launch {
            while (isActive) {
                if (_simState.value == SimulationState.RUNNING) {
                    tickCount++
                    _telemetry.value = generateScenarioTick(_activeScenario.value, tickCount)
                }
                delay(800L) // 800ms telemetry sampling rate
            }
        }
    }

    fun pause() {
        if (_simState.value == SimulationState.RUNNING) {
            _simState.value = SimulationState.PAUSED
            // Mark telemetry as stale after pause threshold
            _telemetry.value = _telemetry.value.copy(isStale = true)
        }
    }

    fun resume() {
        if (_simState.value == SimulationState.PAUSED) {
            _simState.value = SimulationState.RUNNING
            _telemetry.value = _telemetry.value.copy(isStale = false)
        }
    }

    fun stop() {
        _simState.value = SimulationState.STOPPED
        job?.cancel()
        job = null
        _telemetry.value = createBaselineTelemetry().copy(isStale = true)
    }

    fun switchScenario(scenario: SimulationScenario) {
        _activeScenario.value = scenario
        if (_simState.value == SimulationState.STOPPED) {
            start(scenario)
        } else {
            _telemetry.value = generateScenarioTick(scenario, tickCount)
        }
    }

    private fun generateScenarioTick(scenario: SimulationScenario, tick: Int): TelemetryData {
        val jitter = (Random.nextFloat() - 0.5f) * 2f
        val now = System.currentTimeMillis()

        return when (scenario) {
            SimulationScenario.NORMAL_DRIVING -> {
                TelemetryData(
                    eyeClosurePerclos = 5.0f + Random.nextFloat() * 4.0f,
                    blinkDurationMs = 150L + Random.nextLong(60),
                    drowsinessLevel = DrowsinessLevel.ALERT,
                    gazeOffRoadSeconds = 0.2f + Random.nextFloat() * 0.3f,
                    distractionType = DistractionType.NONE,
                    pitchDeg = 1.0f + jitter * 0.5f,
                    rollDeg = 0.2f + jitter * 0.3f,
                    yawDeg = 0.5f + jitter * 0.8f,
                    headNoddingDetected = false,
                    alcoholMgL = 0.00f,
                    alcoholState = AlcoholState.CLEAR,
                    timestamp = now,
                    source = DataSource.SIMULATED_DEMO,
                    isStale = false
                )
            }

            SimulationScenario.FATIGUE_WARNING -> {
                val cycle = (tick % 6)
                val heavyLids = cycle >= 3
                val perclosVal = if (heavyLids) 48.0f + Random.nextFloat() * 12.0f else 32.0f + Random.nextFloat() * 6.0f
                TelemetryData(
                    eyeClosurePerclos = perclosVal,
                    blinkDurationMs = if (heavyLids) 920L + Random.nextLong(200) else 450L + Random.nextLong(80),
                    drowsinessLevel = if (heavyLids) DrowsinessLevel.SEVERE_FATIGUE else DrowsinessLevel.MILD_FATIGUE,
                    gazeOffRoadSeconds = 0.5f,
                    distractionType = DistractionType.NONE,
                    pitchDeg = -14.0f + jitter * 2f,
                    rollDeg = 3.0f,
                    yawDeg = 1.0f,
                    headNoddingDetected = heavyLids && Random.nextBoolean(),
                    alcoholMgL = 0.00f,
                    alcoholState = AlcoholState.CLEAR,
                    timestamp = now,
                    source = DataSource.SIMULATED_DEMO,
                    isStale = false
                )
            }

            SimulationScenario.DISTRACTION_WARNING -> {
                val lookingDown = (tick % 4) >= 1
                val gazeSecs = if (lookingDown) 3.8f + Random.nextFloat() * 1.5f else 0.8f
                TelemetryData(
                    eyeClosurePerclos = 8.0f + Random.nextFloat() * 3.0f,
                    blinkDurationMs = 170L,
                    drowsinessLevel = DrowsinessLevel.ALERT,
                    gazeOffRoadSeconds = gazeSecs,
                    distractionType = if (lookingDown) DistractionType.PHONE_LOOKDOWN else DistractionType.GAZE_RIGHT,
                    pitchDeg = if (lookingDown) -22.0f else 2.0f,
                    rollDeg = if (lookingDown) -8.0f else 1.0f,
                    yawDeg = if (lookingDown) 18.0f else 4.0f,
                    headNoddingDetected = false,
                    alcoholMgL = 0.00f,
                    alcoholState = AlcoholState.CLEAR,
                    timestamp = now,
                    source = DataSource.SIMULATED_DEMO,
                    isStale = false
                )
            }

            SimulationScenario.ABNORMAL_HEAD_MOVEMENT -> {
                val isDropping = (tick % 3) == 0
                TelemetryData(
                    eyeClosurePerclos = 22.0f + Random.nextFloat() * 8.0f,
                    blinkDurationMs = 380L,
                    drowsinessLevel = DrowsinessLevel.MILD_FATIGUE,
                    gazeOffRoadSeconds = 1.2f,
                    distractionType = DistractionType.NONE,
                    pitchDeg = if (isDropping) -34.0f else -6.0f,
                    rollDeg = if (isDropping) 18.0f else 2.0f,
                    yawDeg = if (isDropping) -24.0f else -2.0f,
                    headNoddingDetected = isDropping,
                    alcoholMgL = 0.00f,
                    alcoholState = AlcoholState.CLEAR,
                    timestamp = now,
                    source = DataSource.SIMULATED_DEMO,
                    isStale = false
                )
            }

            SimulationScenario.ALCOHOL_WARNING -> {
                val alcoholVal = 0.09f + (Random.nextFloat() * 0.03f)
                TelemetryData(
                    eyeClosurePerclos = 12.0f + Random.nextFloat() * 4.0f,
                    blinkDurationMs = 210L,
                    drowsinessLevel = DrowsinessLevel.ALERT,
                    gazeOffRoadSeconds = 0.8f,
                    distractionType = DistractionType.NONE,
                    pitchDeg = 0.5f,
                    rollDeg = -1.0f,
                    yawDeg = 0.0f,
                    headNoddingDetected = false,
                    alcoholMgL = alcoholVal,
                    alcoholState = AlcoholState.DANGER,
                    timestamp = now,
                    source = DataSource.SIMULATED_DEMO,
                    isStale = false
                )
            }

            SimulationScenario.MULTIPLE_RISK -> {
                TelemetryData(
                    eyeClosurePerclos = 52.0f + Random.nextFloat() * 10.0f,
                    blinkDurationMs = 880L + Random.nextLong(150),
                    drowsinessLevel = DrowsinessLevel.SEVERE_FATIGUE,
                    gazeOffRoadSeconds = 4.2f + Random.nextFloat(),
                    distractionType = DistractionType.PHONE_LOOKDOWN,
                    pitchDeg = -28.0f + jitter * 3f,
                    rollDeg = 14.0f + jitter * 2f,
                    yawDeg = 20.0f + jitter * 4f,
                    headNoddingDetected = true,
                    alcoholMgL = 0.065f,
                    alcoholState = AlcoholState.WARNING,
                    timestamp = now,
                    source = DataSource.SIMULATED_DEMO,
                    isStale = false
                )
            }
        }
    }

    private fun createBaselineTelemetry(): TelemetryData {
        return TelemetryData(
            eyeClosurePerclos = 6.2f,
            blinkDurationMs = 180L,
            drowsinessLevel = DrowsinessLevel.ALERT,
            gazeOffRoadSeconds = 0.3f,
            distractionType = DistractionType.NONE,
            pitchDeg = 1.0f,
            rollDeg = 0.0f,
            yawDeg = 0.0f,
            headNoddingDetected = false,
            alcoholMgL = 0.00f,
            alcoholState = AlcoholState.CLEAR,
            timestamp = System.currentTimeMillis(),
            source = DataSource.SIMULATED_DEMO,
            isStale = true
        )
    }
}
