package com.example.services

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import com.example.models.BleConnectionState
import com.example.models.BleGlassesState
import com.example.models.GlassesBleConstants
import com.example.models.TelemetryData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class BleGlassesManager(private val context: Context) {

    private val bluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val _glassesState = MutableStateFlow(
        BleGlassesState(
            connectionState = BleConnectionState.DISCONNECTED,
            isHardwareConnected = false,
            statusMessage = "Hardware Not Connected"
        )
    )
    val glassesState: StateFlow<BleGlassesState> = _glassesState.asStateFlow()

    private val _scannedDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val scannedDevices: StateFlow<List<BluetoothDevice>> = _scannedDevices.asStateFlow()

    private var activeGatt: BluetoothGatt? = null

    // Telemetry callback when physical hardware streams packets
    var onPhysicalTelemetryReceived: ((TelemetryData) -> Unit)? = null

    val isBluetoothSupported: Boolean
        get() = bluetoothAdapter != null

    val isBluetoothEnabled: Boolean
        get() = bluetoothAdapter?.isEnabled == true

    @SuppressLint("MissingPermission")
    fun startScan() {
        val adapter = bluetoothAdapter
        if (adapter == null || !adapter.isEnabled) {
            _glassesState.value = _glassesState.value.copy(
                connectionState = BleConnectionState.ERROR,
                statusMessage = if (adapter == null) "Bluetooth LE unsupported on this platform" else "Bluetooth is disabled"
            )
            return
        }

        val scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            _glassesState.value = _glassesState.value.copy(
                connectionState = BleConnectionState.ERROR,
                statusMessage = "BLE Scanner unavailable"
            )
            return
        }

        _scannedDevices.value = emptyList()
        _glassesState.value = _glassesState.value.copy(
            connectionState = BleConnectionState.SCANNING,
            statusMessage = "Scanning for ESP32-S3 AI Drive Glasses..."
        )

        try {
            scanner.startScan(scanCallback)
        } catch (e: SecurityException) {
            _glassesState.value = _glassesState.value.copy(
                connectionState = BleConnectionState.ERROR,
                statusMessage = "Bluetooth scan permission missing: ${e.localizedMessage}"
            )
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        try {
            bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
        } catch (_: Exception) { }

        if (_glassesState.value.connectionState == BleConnectionState.SCANNING) {
            _glassesState.value = _glassesState.value.copy(
                connectionState = BleConnectionState.DISCONNECTED,
                statusMessage = "Hardware Not Connected (Scan stopped)"
            )
        }
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result?.device?.let { device ->
                val name = device.name ?: ""
                val currentList = _scannedDevices.value.toMutableList()
                if (currentList.none { it.address == device.address }) {
                    currentList.add(device)
                    _scannedDevices.value = currentList
                }
                // Auto-match AI-Drive prefix if detected
                if (name.startsWith(GlassesBleConstants.DEVICE_NAME_PREFIX, ignoreCase = true)) {
                    connectToDevice(device)
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            _glassesState.value = _glassesState.value.copy(
                connectionState = BleConnectionState.ERROR,
                statusMessage = "BLE Scan failed (Code $errorCode)"
            )
        }
    }

    @SuppressLint("MissingPermission")
    fun connectToDevice(device: BluetoothDevice) {
        stopScan()
        _glassesState.value = _glassesState.value.copy(
            connectionState = BleConnectionState.CONNECTING,
            deviceName = device.name ?: "ESP32-S3 Smart Glass",
            deviceAddress = device.address,
            statusMessage = "Connecting to GATT server..."
        )

        try {
            activeGatt = device.connectGatt(context, false, gattCallback)
        } catch (e: SecurityException) {
            _glassesState.value = _glassesState.value.copy(
                connectionState = BleConnectionState.ERROR,
                statusMessage = "Bluetooth connect permission missing: ${e.localizedMessage}"
            )
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        _glassesState.value = _glassesState.value.copy(
            connectionState = BleConnectionState.DISCONNECTING,
            statusMessage = "Disconnecting..."
        )
        activeGatt?.disconnect()
        activeGatt?.close()
        activeGatt = null
        _glassesState.value = BleGlassesState(
            connectionState = BleConnectionState.DISCONNECTED,
            isHardwareConnected = false,
            statusMessage = "Hardware Not Connected"
        )
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt?.discoverServices()
                _glassesState.value = _glassesState.value.copy(
                    connectionState = BleConnectionState.CONNECTING,
                    statusMessage = "Discovering GATT services..."
                )
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                _glassesState.value = BleGlassesState(
                    connectionState = BleConnectionState.DISCONNECTED,
                    isHardwareConnected = false,
                    statusMessage = "Hardware Not Connected (Disconnected)"
                )
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val service = gatt?.getService(UUID.fromString(GlassesBleConstants.DEFAULT_SERVICE_UUID))
                val characteristic = service?.getCharacteristic(UUID.fromString(GlassesBleConstants.TELEMETRY_CHAR_UUID))
                if (characteristic != null) {
                    gatt.setCharacteristicNotification(characteristic, true)
                    _glassesState.value = _glassesState.value.copy(
                        connectionState = BleConnectionState.CONNECTED,
                        isHardwareConnected = true,
                        ov2640CameraOnline = true,
                        mpu6050ImuOnline = true,
                        mq3AlcoholSensorOnline = true,
                        statusMessage = "Connected: Telemetry streaming from ESP32-S3"
                    )
                } else {
                    _glassesState.value = _glassesState.value.copy(
                        connectionState = BleConnectionState.CONNECTED,
                        statusMessage = "Connected (Custom telemetry characteristic pending)"
                    )
                }
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?
        ) {
            characteristic?.value?.let { bytes ->
                parseHardwareTelemetryPacket(bytes)
            }
        }
    }

    /**
     * Parses incoming ESP32-S3 packets: supports both JSON payload specified in architecture
     * and compact binary byte packets.
     */
    private fun parseHardwareTelemetryPacket(bytes: ByteArray) {
        if (bytes.isEmpty()) return
        try {
            val text = String(bytes).trim()
            if (text.startsWith("{") && text.endsWith("}")) {
                // Parse JSON packet format:
                // { "deviceId": "AI-DRIVE-001", "timestamp": 1791504000, "fatigue": "HIGH", ... }
                val parsed = com.example.models.Esp32GlassesJsonPacket.parseJson(text)
                if (parsed.isSuccess) {
                    val pkt = parsed.getOrThrow()
                    val drowsiness = when (pkt.fatigue.uppercase()) {
                        "HIGH", "CRITICAL" -> com.example.models.DrowsinessLevel.SEVERE_FATIGUE
                        "MEDIUM", "WARNING" -> com.example.models.DrowsinessLevel.MILD_FATIGUE
                        else -> com.example.models.DrowsinessLevel.ALERT
                    }
                    val distraction = when (pkt.distraction.uppercase()) {
                        "HIGH" -> com.example.models.DistractionType.PHONE_LOOKDOWN
                        "MEDIUM" -> com.example.models.DistractionType.GAZE_RIGHT
                        else -> com.example.models.DistractionType.NONE
                    }
                    val isNodding = pkt.headMovement.contains("NOD", ignoreCase = true) ||
                            pkt.headMovement.equals("ABNORMAL", ignoreCase = true)
                    val alcoholState = when (pkt.alcohol.uppercase()) {
                        "WARNING" -> com.example.models.AlcoholState.WARNING
                        "CRITICAL", "DANGER" -> com.example.models.AlcoholState.DANGER
                        "NORMAL", "CLEAR" -> com.example.models.AlcoholState.CLEAR
                        else -> com.example.models.AlcoholState.SENSOR_WARMING_UP
                    }

                    val telemetry = TelemetryData(
                        eyeClosurePerclos = if (drowsiness == com.example.models.DrowsinessLevel.SEVERE_FATIGUE) 45f else 8f,
                        blinkDurationMs = if (drowsiness == com.example.models.DrowsinessLevel.SEVERE_FATIGUE) 850L else 180L,
                        drowsinessLevel = drowsiness,
                        gazeOffRoadSeconds = if (distraction != com.example.models.DistractionType.NONE) 3.2f else 0.2f,
                        distractionType = distraction,
                        pitchDeg = if (isNodding) -28f else 1f,
                        headNoddingDetected = isNodding,
                        alcoholMgL = if (alcoholState == com.example.models.AlcoholState.DANGER) 0.09f else 0.00f,
                        alcoholState = alcoholState,
                        source = com.example.models.DataSource.ESP32_S3_BLE,
                        isStale = false
                    )
                    onPhysicalTelemetryReceived?.invoke(telemetry)
                    return
                }
            }

            if (bytes.size >= 11) {
                // Parse binary byte stream fallback
                val perclos = ((bytes[0].toInt() and 0xFF) or ((bytes[1].toInt() and 0xFF) shl 8)) / 10f
                val blinkMs = ((bytes[2].toInt() and 0xFF) or ((bytes[3].toInt() and 0xFF) shl 8)).toLong()
                val pitch = (((bytes[4].toInt() and 0xFF) or (bytes[5].toInt() shl 8))).toFloat() / 10f
                val roll = (((bytes[6].toInt() and 0xFF) or (bytes[7].toInt() shl 8))).toFloat() / 10f
                val alcoholMgL = ((bytes[8].toInt() and 0xFF) or ((bytes[9].toInt() and 0xFF) shl 8)) / 1000f
                val flags = bytes[10].toInt() and 0xFF

                val isDrowsy = (flags and 0x01) != 0
                val isDistracted = (flags and 0x02) != 0
                val isNodding = (flags and 0x04) != 0

                val telemetry = TelemetryData(
                    eyeClosurePerclos = perclos,
                    blinkDurationMs = blinkMs,
                    drowsinessLevel = if (isDrowsy) com.example.models.DrowsinessLevel.SEVERE_FATIGUE else com.example.models.DrowsinessLevel.ALERT,
                    gazeOffRoadSeconds = if (isDistracted) 3.0f else 0.2f,
                    distractionType = if (isDistracted) com.example.models.DistractionType.PHONE_LOOKDOWN else com.example.models.DistractionType.NONE,
                    pitchDeg = pitch,
                    rollDeg = roll,
                    headNoddingDetected = isNodding,
                    alcoholMgL = alcoholMgL,
                    alcoholState = if (alcoholMgL > 0.05f) com.example.models.AlcoholState.WARNING else com.example.models.AlcoholState.CLEAR,
                    source = com.example.models.DataSource.ESP32_S3_BLE,
                    isStale = false
                )
                onPhysicalTelemetryReceived?.invoke(telemetry)
            }
        } catch (_: Exception) { }
    }
}
