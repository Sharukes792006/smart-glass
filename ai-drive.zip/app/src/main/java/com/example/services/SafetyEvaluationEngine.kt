package com.example.services

import com.example.models.AlertCategory
import com.example.models.AlertSeverity
import com.example.models.DrowsinessLevel
import com.example.models.SafetyAlert
import com.example.models.SafetyScore
import com.example.models.SafetyStatus
import com.example.models.TelemetryData
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

object SafetyEvaluationEngine {

    // Thresholds
    const val PERCLOS_WARNING_THRESHOLD = 25.0f
    const val PERCLOS_CRITICAL_THRESHOLD = 40.0f
    const val GAZE_OFF_ROAD_WARNING_SEC = 2.0f
    const val GAZE_OFF_ROAD_CRITICAL_SEC = 3.5f
    const val ALCOHOL_WARNING_MGL = 0.04f
    const val ALCOHOL_CRITICAL_MGL = 0.08f
    const val HEAD_PITCH_NOD_THRESHOLD_DEG = 25.0f

    fun calculateSafetyScore(telemetry: TelemetryData): SafetyScore {
        var fatiguePenalty = 0
        var distractionPenalty = 0
        var headPenalty = 0
        var alcoholPenalty = 0

        // 1. Fatigue Analysis (PERCLOS & Drowsiness)
        if (telemetry.eyeClosurePerclos > PERCLOS_CRITICAL_THRESHOLD ||
            telemetry.drowsinessLevel == DrowsinessLevel.SEVERE_FATIGUE
        ) {
            fatiguePenalty = 35
        } else if (telemetry.eyeClosurePerclos > PERCLOS_WARNING_THRESHOLD ||
            telemetry.drowsinessLevel == DrowsinessLevel.MILD_FATIGUE
        ) {
            fatiguePenalty = 18
        }

        // 2. Distraction Analysis (Gaze & Lookdown)
        if (telemetry.gazeOffRoadSeconds > GAZE_OFF_ROAD_CRITICAL_SEC ||
            telemetry.distractionType == com.example.models.DistractionType.PHONE_LOOKDOWN
        ) {
            distractionPenalty = 30
        } else if (telemetry.gazeOffRoadSeconds > GAZE_OFF_ROAD_WARNING_SEC) {
            distractionPenalty = 15
        }

        // 3. Head Posture Analysis (MPU6050 gyro/pitch)
        if (telemetry.headNoddingDetected) {
            headPenalty = 25
        } else if (abs(telemetry.pitchDeg) > HEAD_PITCH_NOD_THRESHOLD_DEG || abs(telemetry.rollDeg) > 30f) {
            headPenalty = 15
        }

        // 4. MQ-3 Alcohol Sensor Analysis
        if (telemetry.alcoholMgL >= ALCOHOL_CRITICAL_MGL) {
            alcoholPenalty = 45
        } else if (telemetry.alcoholMgL >= ALCOHOL_WARNING_MGL) {
            alcoholPenalty = 22
        }

        val totalPenalty = fatiguePenalty + distractionPenalty + headPenalty + alcoholPenalty
        val computedScore = max(0, 100 - totalPenalty)

        val status = when {
            computedScore >= 90 -> SafetyStatus.OPTIMAL
            computedScore >= 75 -> SafetyStatus.SAFE
            computedScore >= 50 -> SafetyStatus.CAUTION
            else -> SafetyStatus.CRITICAL
        }

        return SafetyScore(
            score = computedScore,
            fatiguePenalty = fatiguePenalty,
            distractionPenalty = distractionPenalty,
            headMovementPenalty = headPenalty,
            alcoholPenalty = alcoholPenalty,
            status = status
        )
    }

    fun detectAlert(telemetry: TelemetryData): SafetyAlert? {
        val now = System.currentTimeMillis()

        // Highest severity first
        if (telemetry.alcoholMgL >= ALCOHOL_CRITICAL_MGL) {
            return SafetyAlert(
                id = UUID.randomUUID().toString(),
                title = "Alcohol Warning: Legal Limit Exceeded",
                message = "MQ-3 detected breath vapor level of ${"%.2f".format(telemetry.alcoholMgL)} mg/L (Limit 0.05 mg/L). Do not operate vehicle.",
                category = AlertCategory.ALCOHOL,
                severity = AlertSeverity.CRITICAL,
                timestamp = now,
                isDemo = telemetry.source == com.example.models.DataSource.SIMULATED_DEMO
            )
        }

        if (telemetry.drowsinessLevel == DrowsinessLevel.SEVERE_FATIGUE ||
            telemetry.eyeClosurePerclos > PERCLOS_CRITICAL_THRESHOLD
        ) {
            return SafetyAlert(
                id = UUID.randomUUID().toString(),
                title = "Critical Fatigue: Micro-Sleep Risk",
                message = "Eye closure PERCLOS at ${"%.1f".format(telemetry.eyeClosurePerclos)}%. Glasses camera detected microsleep tendency. Pull over immediately.",
                category = AlertCategory.FATIGUE,
                severity = AlertSeverity.CRITICAL,
                timestamp = now,
                isDemo = telemetry.source == com.example.models.DataSource.SIMULATED_DEMO
            )
        }

        if (telemetry.headNoddingDetected) {
            return SafetyAlert(
                id = UUID.randomUUID().toString(),
                title = "Head Drop Anomaly Detected",
                message = "MPU6050 6-axis IMU detected sudden nodding motion consistent with falling asleep at the wheel.",
                category = AlertCategory.HEAD_MOVEMENT,
                severity = AlertSeverity.CRITICAL,
                timestamp = now,
                isDemo = telemetry.source == com.example.models.DataSource.SIMULATED_DEMO
            )
        }

        if (telemetry.gazeOffRoadSeconds > GAZE_OFF_ROAD_CRITICAL_SEC ||
            telemetry.distractionType == com.example.models.DistractionType.PHONE_LOOKDOWN
        ) {
            return SafetyAlert(
                id = UUID.randomUUID().toString(),
                title = "Distraction: Eyes Off Roadway",
                message = "Gaze diverted from road for ${"%.1f".format(telemetry.gazeOffRoadSeconds)}s. Possible phone usage detected by smart glasses optics.",
                category = AlertCategory.DISTRACTION,
                severity = AlertSeverity.CRITICAL,
                timestamp = now,
                isDemo = telemetry.source == com.example.models.DataSource.SIMULATED_DEMO
            )
        }

        if (telemetry.drowsinessLevel == DrowsinessLevel.MILD_FATIGUE ||
            telemetry.eyeClosurePerclos > PERCLOS_WARNING_THRESHOLD
        ) {
            return SafetyAlert(
                id = UUID.randomUUID().toString(),
                title = "Mild Drowsiness Warning",
                message = "Blink rate slowing down (${telemetry.blinkDurationMs}ms). Consider taking a rest stop soon.",
                category = AlertCategory.FATIGUE,
                severity = AlertSeverity.WARNING,
                timestamp = now,
                isDemo = telemetry.source == com.example.models.DataSource.SIMULATED_DEMO
            )
        }

        if (telemetry.gazeOffRoadSeconds > GAZE_OFF_ROAD_WARNING_SEC) {
            return SafetyAlert(
                id = UUID.randomUUID().toString(),
                title = "Minor Distraction Detected",
                message = "Off-center gaze detected. Keep attention focused on roadway ahead.",
                category = AlertCategory.DISTRACTION,
                severity = AlertSeverity.WARNING,
                timestamp = now,
                isDemo = telemetry.source == com.example.models.DataSource.SIMULATED_DEMO
            )
        }

        if (telemetry.alcoholMgL >= ALCOHOL_WARNING_MGL) {
            return SafetyAlert(
                id = UUID.randomUUID().toString(),
                title = "Trace Alcohol Detected",
                message = "MQ-3 sensor registered trace alcohol levels (${"%.2f".format(telemetry.alcoholMgL)} mg/L).",
                category = AlertCategory.ALCOHOL,
                severity = AlertSeverity.WARNING,
                timestamp = now,
                isDemo = telemetry.source == com.example.models.DataSource.SIMULATED_DEMO
            )
        }

        return null
    }
}
