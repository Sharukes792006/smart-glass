package com.example.services.camera

import android.graphics.ImageFormat
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.example.models.DistractionType
import com.example.models.DrowsinessLevel
import com.example.models.TelemetryData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.nio.ByteBuffer
import kotlin.math.abs

data class CameraDmsTelemetry(
    val isFaceDetected: Boolean = false,
    val eyeClosurePerclos: Float = 0f,
    val blinkDurationMs: Long = 180L,
    val drowsinessLevel: DrowsinessLevel = DrowsinessLevel.ALERT,
    val gazeOffRoadSeconds: Float = 0f,
    val distractionType: DistractionType = DistractionType.NONE,
    val fps: Float = 0f,
    val averageLuminance: Float = 0f,
    val isDrowsyAlert: Boolean = false
)

class DriverFatigueAnalyzer(
    private val onTelemetryExtracted: ((TelemetryData) -> Unit)? = null
) : ImageAnalysis.Analyzer {

    private val _dmsTelemetry = MutableStateFlow(CameraDmsTelemetry())
    val dmsTelemetry: StateFlow<CameraDmsTelemetry> = _dmsTelemetry.asStateFlow()

    private var frameCount = 0L
    private var lastFpsTimestamp = System.currentTimeMillis()
    private var currentFps = 0f

    // Moving window of 30 frames for PERCLOS calculation
    private val eyeClosureHistory = ArrayDeque<Boolean>()
    private val HISTORY_WINDOW_SIZE = 30

    private var closedEyeStartTimeMs: Long? = null
    private var lastBlinkDurationMs = 180L
    private var offRoadGazeStartTimeMs: Long? = null

    override fun analyze(image: ImageProxy) {
        val now = System.currentTimeMillis()
        frameCount++

        // Calculate frame rate
        if (now - lastFpsTimestamp >= 1000L) {
            currentFps = frameCount * 1000f / (now - lastFpsTimestamp)
            frameCount = 0
            lastFpsTimestamp = now
        }

        try {
            // Process Y plane (Luminance) for fast low-overhead on-device vision
            val plane = image.planes[0]
            val buffer = plane.buffer
            val width = image.width
            val height = image.height

            val luminanceAnalysis = analyzeLuminance(buffer, width, height)

            // Evaluate driver eye closure from upper central quadrant (typical eye box in automotive DMS mounts)
            val isEyeClosed = luminanceAnalysis.isEyeClosedCandidate
            val isFaceCentered = luminanceAnalysis.isFaceCandidate

            // Update rolling PERCLOS window
            if (eyeClosureHistory.size >= HISTORY_WINDOW_SIZE) {
                eyeClosureHistory.removeFirst()
            }
            eyeClosureHistory.addLast(isEyeClosed)

            val closedCount = eyeClosureHistory.count { it }
            val perclos = (closedCount.toFloat() / eyeClosureHistory.size.coerceAtLeast(1)) * 100f

            // Blink timing & micro-sleep duration detection
            if (isEyeClosed) {
                if (closedEyeStartTimeMs == null) {
                    closedEyeStartTimeMs = now
                }
            } else {
                if (closedEyeStartTimeMs != null) {
                    lastBlinkDurationMs = (now - closedEyeStartTimeMs!!).coerceIn(100L, 2500L)
                    closedEyeStartTimeMs = null
                }
            }

            val eyeClosedDurationMs = closedEyeStartTimeMs?.let { now - it } ?: 0L

            // Gaze deviation check
            val isGazeDiverted = luminanceAnalysis.isGazeOffRoad
            if (isGazeDiverted) {
                if (offRoadGazeStartTimeMs == null) {
                    offRoadGazeStartTimeMs = now
                }
            } else {
                offRoadGazeStartTimeMs = null
            }
            val gazeOffRoadSec = offRoadGazeStartTimeMs?.let { (now - it) / 1000f } ?: 0f

            // Categorize fatigue & drowsiness
            val drowsiness = when {
                perclos > 40f || eyeClosedDurationMs > 1200L -> DrowsinessLevel.SEVERE_FATIGUE
                perclos > 22f || eyeClosedDurationMs > 600L -> DrowsinessLevel.MILD_FATIGUE
                else -> DrowsinessLevel.ALERT
            }

            val distraction = when {
                gazeOffRoadSec > 3.0f -> DistractionType.PHONE_LOOKDOWN
                gazeOffRoadSec > 1.5f -> DistractionType.GAZE_RIGHT
                else -> DistractionType.NONE
            }

            val result = CameraDmsTelemetry(
                isFaceDetected = isFaceCentered,
                eyeClosurePerclos = perclos,
                blinkDurationMs = lastBlinkDurationMs,
                drowsinessLevel = drowsiness,
                gazeOffRoadSeconds = gazeOffRoadSec,
                distractionType = distraction,
                fps = currentFps,
                averageLuminance = luminanceAnalysis.averageLuminance,
                isDrowsyAlert = drowsiness == DrowsinessLevel.SEVERE_FATIGUE
            )

            _dmsTelemetry.value = result

            // Forward to safety evaluation
            onTelemetryExtracted?.invoke(
                TelemetryData(
                    eyeClosurePerclos = perclos,
                    blinkDurationMs = lastBlinkDurationMs,
                    drowsinessLevel = drowsiness,
                    gazeOffRoadSeconds = gazeOffRoadSec,
                    distractionType = distraction,
                    pitchDeg = if (isEyeClosed && eyeClosedDurationMs > 800L) -20f else 0f,
                    headNoddingDetected = eyeClosedDurationMs > 1500L,
                    alcoholMgL = 0.00f,
                    timestamp = now,
                    source = com.example.models.DataSource.ESP32_S3_BLE, // Live camera feed
                    isStale = false
                )
            )
        } catch (_: Exception) {
        } finally {
            image.close()
        }
    }

    private data class LuminanceResult(
        val averageLuminance: Float,
        val isEyeClosedCandidate: Boolean,
        val isFaceCandidate: Boolean,
        val isGazeOffRoad: Boolean
    )

    private fun analyzeLuminance(buffer: ByteBuffer, width: Int, height: Int): LuminanceResult {
        var totalLuminance = 0L
        var sampleCount = 0

        // Subsample pixels for 30+ FPS performance without thermal strain
        val step = 8
        val eyeRegionYStart = (height * 0.25).toInt()
        val eyeRegionYEnd = (height * 0.55).toInt()
        val eyeRegionXStart = (width * 0.2).toInt()
        val eyeRegionXEnd = (width * 0.8).toInt()

        var eyeRegionLuminance = 0L
        var eyeSampleCount = 0

        var leftQuadrantLuminance = 0L
        var rightQuadrantLuminance = 0L

        buffer.rewind()
        val remaining = buffer.remaining()

        for (y in 0 until height step step) {
            for (x in 0 until width step step) {
                val index = y * width + x
                if (index < remaining) {
                    val pixel = buffer.get(index).toInt() and 0xFF
                    totalLuminance += pixel
                    sampleCount++

                    if (y in eyeRegionYStart..eyeRegionYEnd && x in eyeRegionXStart..eyeRegionXEnd) {
                        eyeRegionLuminance += pixel
                        eyeSampleCount++

                        if (x < width / 2) {
                            leftQuadrantLuminance += pixel
                        } else {
                            rightQuadrantLuminance += pixel
                        }
                    }
                }
            }
        }

        val avgTotal = if (sampleCount > 0) totalLuminance.toFloat() / sampleCount else 128f
        val avgEyeRegion = if (eyeSampleCount > 0) eyeRegionLuminance.toFloat() / eyeSampleCount else 128f

        // When eyelids close, specular reflection from the cornea drops
        val isClosed = (avgEyeRegion < avgTotal * 0.82f) && avgEyeRegion > 20f

        // Gaze asymmetry between left and right facial quadrants indicates head rotation
        val leftAvg = if (eyeSampleCount > 0) leftQuadrantLuminance.toFloat() / (eyeSampleCount / 2).coerceAtLeast(1) else 128f
        val rightAvg = if (eyeSampleCount > 0) rightQuadrantLuminance.toFloat() / (eyeSampleCount / 2).coerceAtLeast(1) else 128f
        val gazeOff = abs(leftAvg - rightAvg) > 35f

        val faceDetected = avgEyeRegion > 30f && avgEyeRegion < 240f

        return LuminanceResult(
            averageLuminance = avgTotal,
            isEyeClosedCandidate = isClosed,
            isFaceCandidate = faceDetected,
            isGazeOffRoad = gazeOff
        )
    }
}
