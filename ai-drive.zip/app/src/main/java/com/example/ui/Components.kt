package com.example.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.models.BleGlassesState
import com.example.models.SafetyScore
import com.example.models.SafetyStatus
import com.example.services.SosUiState
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.ClayAmbientShadow
import com.example.ui.theme.ClayCyanRim
import com.example.ui.theme.ClayDarkShadow
import com.example.ui.theme.ClayHighlightRim
import com.example.ui.theme.ClaySurfaceBottom
import com.example.ui.theme.ClaySurfaceElevatedBottom
import com.example.ui.theme.ClaySurfaceElevatedTop
import com.example.ui.theme.ClaySurfaceTop
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.WarningAmber

/**
 * 3D Soft Claymorphic Container with pillowy depth, top highlight rim, and soft ambient shadow.
 */
@Composable
fun ClayCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(26.dp),
    isElevated: Boolean = false,
    rimColor: Color = ClayHighlightRim,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val topColor = if (isElevated) ClaySurfaceElevatedTop else ClaySurfaceTop
    val bottomColor = if (isElevated) ClaySurfaceElevatedBottom else ClaySurfaceBottom

    val baseModifier = modifier
        .shadow(
            elevation = if (isElevated) 14.dp else 8.dp,
            shape = shape,
            ambientColor = ClayAmbientShadow,
            spotColor = ClayDarkShadow
        )
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(topColor, bottomColor)
            )
        )
        .border(
            width = 1.5.dp,
            brush = Brush.verticalGradient(
                listOf(rimColor, Color(0x05FFFFFF))
            ),
            shape = shape
        )

    val finalModifier = if (onClick != null) {
        baseModifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = ripple(color = CyanAccent),
            onClick = onClick
        )
    } else {
        baseModifier
    }

    Box(modifier = finalModifier) {
        content()
    }
}

/**
 * 3D Tactile Clay Button with pillowy gradient and soft glow.
 */
@Composable
fun ClayButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    gradientColors: List<Color> = listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
    textColor: Color = TextOnCyan,
    enabled: Boolean = true
) {
    Box(
        modifier = modifier
            .shadow(
                elevation = if (enabled) 8.dp else 2.dp,
                shape = RoundedCornerShape(20.dp),
                ambientColor = ClayAmbientShadow,
                spotColor = ClayDarkShadow
            )
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (enabled) Brush.verticalGradient(gradientColors)
                else Brush.verticalGradient(listOf(Color(0xFF2A374A), Color(0xFF1B2433)))
            )
            .border(
                1.5.dp,
                Brush.verticalGradient(listOf(Color(0x70FFFFFF), Color(0x10FFFFFF))),
                RoundedCornerShape(20.dp)
            )
            .clickable(
                enabled = enabled,
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(color = Color.White),
                onClick = onClick
            )
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (enabled) textColor else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                color = if (enabled) textColor else TextMuted,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                letterSpacing = 0.5.sp
            )
        }
    }
}

/**
 * Minimal, user-friendly 3D Clay Safety Score Orb with circular tactile rim.
 */
@Composable
fun ClayScoreOrb(
    safetyScore: SafetyScore,
    modifier: Modifier = Modifier,
    size: Dp = 190.dp
) {
    val animatedScore by animateFloatAsState(
        targetValue = safetyScore.score.toFloat(),
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "clayScoreAnim"
    )

    val gaugeColor by animateColorAsState(
        targetValue = when (safetyScore.status) {
            SafetyStatus.OPTIMAL -> CyanAccent
            SafetyStatus.SAFE -> SafetyGreen
            SafetyStatus.CAUTION -> WarningAmber
            SafetyStatus.CRITICAL -> CriticalRed
        },
        label = "clayColorAnim"
    )

    Box(
        modifier = modifier
            .size(size)
            .shadow(16.dp, CircleShape, ambientColor = ClayAmbientShadow, spotColor = ClayDarkShadow)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(ClaySurfaceElevatedTop, ClaySurfaceBottom)
                )
            )
            .border(
                2.dp,
                Brush.verticalGradient(listOf(ClayHighlightRim, Color(0x05FFFFFF))),
                CircleShape
            )
            .testTag("safety_gauge_box"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(14.dp)) {
            val strokeW = 12.dp.toPx()

            // Subtle track
            drawArc(
                color = Color(0x1AFFFFFF),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )

            // Neon glowing clay progress arc
            val sweep = (animatedScore / 100f) * 270f
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(
                        TurquoiseAccent,
                        gaugeColor,
                        gaugeColor
                    )
                ),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "${safetyScore.score}",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 50.sp
                )
            )
            Text(
                text = "SAFETY SCORE",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.4.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.SemiBold
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(gaugeColor.copy(alpha = 0.16f))
                    .border(1.dp, gaugeColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 3.dp)
            ) {
                Text(
                    text = safetyScore.status.name,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = gaugeColor,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                )
            }
        }
    }
}

/**
 * Clean, tactile, user-friendly 3D Clay Sensor Tile with less cognitive clutter.
 */
@Composable
fun ClaySensorTile(
    title: String,
    value: String,
    statusText: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    progress: Float? = null,
    alertActive: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    ClayCard(
        modifier = modifier.testTag("sensor_card_$title"),
        rimColor = if (alertActive) CriticalRed.copy(alpha = 0.6f) else ClayHighlightRim,
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.16f))
                        .border(1.dp, accentColor.copy(alpha = 0.4f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                if (alertActive) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .shadow(4.dp, CircleShape, spotColor = CriticalRed)
                            .clip(CircleShape)
                            .background(CriticalRed)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 22.sp
                )
            )

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = statusText,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = accentColor,
                    fontWeight = FontWeight.Medium,
                    fontSize = 11.sp
                )
            )

            if (progress != null) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = accentColor,
                    trackColor = Color(0x1FFFFFFF)
                )
            }
        }
    }
}

/**
 * Minimalist, friendly DEMO MODE Capsule.
 */
@Composable
fun ClayDemoCapsule(
    onScenarioClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    ClayCard(
        modifier = modifier.fillMaxWidth().testTag("demo_mode_banner"),
        shape = RoundedCornerShape(20.dp),
        rimColor = ClayCyanRim,
        onClick = onScenarioClick
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(CyanAccent.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Sensors,
                        contentDescription = "Demo Mode",
                        tint = CyanAccent,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "DEMO SIMULATION ACTIVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "Synthetic telemetry • Tap to switch driving scenario",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyanAccent.copy(alpha = 0.15f))
                    .border(1.dp, CyanAccent.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "Switch",
                    color = CyanAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Pill-shaped tactile Bluetooth indicator.
 */
@Composable
fun ClayGlassesPill(
    bleState: BleGlassesState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColor = if (bleState.isHardwareConnected) SafetyGreen else TextMuted
    Box(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(18.dp), ambientColor = ClayAmbientShadow)
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(
                    listOf(ClaySurfaceElevatedTop, ClaySurfaceBottom)
                )
            )
            .border(
                1.dp,
                if (bleState.isHardwareConnected) SafetyGreen.copy(alpha = 0.6f) else ClayHighlightRim,
                RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("glasses_hardware_chip"),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (bleState.isHardwareConnected) Icons.Default.Bluetooth else Icons.Default.BluetoothDisabled,
                contentDescription = "Bluetooth Status",
                tint = statusColor,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (bleState.isHardwareConnected) "Glasses Paired" else "Hardware Offline",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = if (bleState.isHardwareConnected) SafetyGreen else TextSecondary
                )
            )
        }
    }
}

/**
 * Tactile Clay Emergency SOS Dialog.
 */
@Composable
fun EmergencySosModal(
    sosState: SosUiState,
    onCancel: () -> Unit,
    onDial: (String) -> Unit,
    onSendSms: (String, String, String) -> Unit,
    onDismiss: () -> Unit
) {
    when (sosState) {
        is SosUiState.CountingDown -> {
            Dialog(
                onDismissRequest = {},
                properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
            ) {
                ClayCard(
                    modifier = Modifier.fillMaxWidth().testTag("emergency_countdown_dialog"),
                    shape = RoundedCornerShape(28.dp),
                    rimColor = CriticalRed
                ) {
                    Column(
                        modifier = Modifier.padding(26.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "EMERGENCY SOS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = CriticalRed,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(18.dp))

                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .shadow(14.dp, CircleShape, spotColor = CriticalRed)
                                .clip(CircleShape)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(0xFFFF5E7E), Color(0xFFD91E48))
                                    )
                                )
                                .border(2.5.dp, Color(0x60FFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${sosState.secondsRemaining}",
                                style = MaterialTheme.typography.displayLarge.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 54.sp
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))
                        Text(
                            text = "Preparing emergency dispatch with live GPS location.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                        )
                        Spacer(modifier = Modifier.height(24.dp))

                        ClayButton(
                            text = "Cancel SOS — I Am Safe",
                            onClick = onCancel,
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("cancel_sos_button"),
                            gradientColors = listOf(Color(0xFF2A3952), Color(0xFF192335)),
                            textColor = TextPrimary
                        )
                    }
                }
            }
        }

        is SosUiState.Prepared -> {
            Dialog(onDismissRequest = onDismiss) {
                ClayCard(
                    modifier = Modifier.fillMaxWidth().testTag("emergency_prepared_dialog"),
                    shape = RoundedCornerShape(28.dp),
                    rimColor = CyanAccent
                ) {
                    Column(modifier = Modifier.padding(22.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Distress Alert Ready",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "GPS Coordinates & Distress message ready to dispatch:",
                            style = MaterialTheme.typography.bodySmall.copy(color = CyanAccent)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x2B000000))
                                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = sosState.event.messageContent,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Primary Contact: ${sosState.contacts.firstOrNull()?.name ?: "Emergency Dispatch"} (${sosState.event.targetPhone})",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        )

                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ClayButton(
                                text = "Open SMS",
                                icon = Icons.Default.Sms,
                                onClick = {
                                    onSendSms(
                                        sosState.event.targetPhone,
                                        sosState.event.messageContent,
                                        sosState.event.id
                                    )
                                },
                                modifier = Modifier.weight(1f).height(48.dp).testTag("open_sms_button"),
                                gradientColors = listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                                textColor = TextOnCyan
                            )

                            ClayButton(
                                text = "Call",
                                icon = Icons.Default.Phone,
                                onClick = { onDial(sosState.event.targetPhone) },
                                modifier = Modifier.weight(1f).height(48.dp).testTag("open_dialer_button"),
                                gradientColors = listOf(Color(0xFFFF5E7E), Color(0xFFD91E48)),
                                textColor = Color.White
                            )
                        }
                    }
                }
            }
        }

        is SosUiState.Cancelled -> {
            Dialog(onDismissRequest = onDismiss) {
                ClayCard(shape = RoundedCornerShape(22.dp)) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SafetyGreen, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("SOS Cancelled", style = MaterialTheme.typography.titleMedium.copy(color = TextPrimary, fontWeight = FontWeight.Bold))
                        Text(sosState.reason, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
                    }
                }
            }
        }

        is SosUiState.Completed -> {
            Dialog(onDismissRequest = onDismiss) {
                ClayCard(shape = RoundedCornerShape(22.dp)) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Emergency Assistance Executed", style = MaterialTheme.typography.titleMedium.copy(color = TextPrimary, fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(sosState.summary, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
                        Spacer(modifier = Modifier.height(16.dp))
                        ClayButton(
                            text = "Done",
                            onClick = onDismiss,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        else -> {}
    }
}
