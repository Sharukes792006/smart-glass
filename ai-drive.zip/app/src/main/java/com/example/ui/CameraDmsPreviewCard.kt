package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.models.DrowsinessLevel
import com.example.services.camera.CameraDmsManager
import com.example.services.camera.CameraFacing
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextOnCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.WarningAmber

@Composable
fun CameraDmsPreviewCard(
    cameraManager: CameraDmsManager,
    isCameraModeActive: Boolean,
    onToggleCameraMode: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (granted) {
            onToggleCameraMode(true)
        }
    }

    val dmsTelemetry by cameraManager.analyzer.dmsTelemetry.collectAsStateWithLifecycle()
    val isCameraActive by cameraManager.isCameraActive.collectAsStateWithLifecycle()
    val currentFacing by cameraManager.currentLensFacing.collectAsStateWithLifecycle()
    val cameraError by cameraManager.cameraError.collectAsStateWithLifecycle()

    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }

    DisposableEffect(isCameraModeActive, hasCameraPermission) {
        onDispose {
            if (!isCameraModeActive) {
                cameraManager.unbindCamera()
            }
        }
    }

    ClayCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("camera_dms_card"),
        shape = RoundedCornerShape(26.dp),
        isElevated = true,
        rimColor = if (dmsTelemetry.isDrowsyAlert) CriticalRed else CyanAccent.copy(alpha = 0.5f)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header with Mode Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CyanAccent.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RemoveRedEye,
                            contentDescription = "Camera DMS",
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "CAMERAX FATIGUE DMS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 14.sp,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = if (isCameraModeActive) "Live Video Stream Active" else "Simulation Bench Active",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isCameraModeActive) SafetyGreen else TurquoiseAccent,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Clay Toggle Button
                ClayButton(
                    text = if (isCameraModeActive) "Use Sim" else "Live Cam",
                    icon = if (isCameraModeActive) Icons.Default.VideocamOff else Icons.Default.Videocam,
                    onClick = {
                        if (!isCameraModeActive) {
                            if (hasCameraPermission) {
                                onToggleCameraMode(true)
                            } else {
                                permissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        } else {
                            onToggleCameraMode(false)
                            cameraManager.unbindCamera()
                        }
                    },
                    gradientColors = if (isCameraModeActive) listOf(Color(0xFF2A374A), Color(0xFF1B2433))
                    else listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                    textColor = if (isCameraModeActive) TextSecondary else TextOnCyan
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (!isCameraModeActive) {
                // Info Banner when camera is off
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x20000000))
                        .border(1.dp, Color(0x10FFFFFF), RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Face,
                            contentDescription = null,
                            tint = TurquoiseAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Tap 'Live Cam' to activate CameraX real-time eye tracking and driver fatigue video analysis from device camera.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 12.sp)
                        )
                    }
                }
            } else if (!hasCameraPermission) {
                // Permission Required Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x20000000))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Camera Permission Required",
                            style = MaterialTheme.typography.titleMedium.copy(color = WarningAmber, fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Please grant camera access to analyze live driver eye blink & fatigue frames.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        ClayButton(
                            text = "Grant Camera Permission",
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }
                        )
                    }
                }
            } else {
                // Live CameraX Preview with HUD Reticle
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.Black)
                        .border(1.dp, if (dmsTelemetry.isDrowsyAlert) CriticalRed else CyanAccent, RoundedCornerShape(18.dp))
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            PreviewView(ctx).also { pView ->
                                previewViewRef = pView
                                cameraManager.bindCameraToLifecycle(lifecycleOwner, pView)
                            }
                        },
                        update = { pView ->
                            previewViewRef = pView
                        }
                    )

                    // HUD Eye Box Reticle & Target Crosshairs
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val boxW = w * 0.5f
                        val boxH = h * 0.35f
                        val left = (w - boxW) / 2f
                        val top = h * 0.28f

                        val reticleColor = if (dmsTelemetry.isDrowsyAlert) CriticalRed else CyanAccent

                        // Corner markers for eye tracking box
                        val cornerLen = 22f
                        drawRect(
                            color = reticleColor.copy(alpha = 0.25f),
                            topLeft = Offset(left, top),
                            size = Size(boxW, boxH),
                            style = Stroke(width = 2f)
                        )

                        // Center eye tracking pupil points
                        drawCircle(
                            color = if (dmsTelemetry.isDrowsyAlert) CriticalRed else SafetyGreen,
                            radius = 6f,
                            center = Offset(left + boxW * 0.35f, top + boxH * 0.5f)
                        )
                        drawCircle(
                            color = if (dmsTelemetry.isDrowsyAlert) CriticalRed else SafetyGreen,
                            radius = 6f,
                            center = Offset(left + boxW * 0.65f, top + boxH * 0.5f)
                        )
                    }

                    // Top HUD status overlay
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x99000000))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "FPS: ${"%.1f".format(dmsTelemetry.fps)} • ${if (currentFacing == CameraFacing.FRONT) "FRONT" else "BACK"}",
                                color = CyanAccent,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(
                            onClick = {
                                previewViewRef?.let { pView ->
                                    cameraManager.toggleCameraFacing(lifecycleOwner, pView)
                                }
                            },
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0x99000000))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cameraswitch,
                                contentDescription = "Switch Camera",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Bottom HUD Status Tag
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Color(0xCC000000))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PERCLOS: ${"%.1f".format(dmsTelemetry.eyeClosurePerclos)}% (Blink: ${dmsTelemetry.blinkDurationMs}ms)",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = dmsTelemetry.drowsinessLevel.name,
                                color = when (dmsTelemetry.drowsinessLevel) {
                                    DrowsinessLevel.ALERT -> SafetyGreen
                                    DrowsinessLevel.MILD_FATIGUE -> WarningAmber
                                    DrowsinessLevel.SEVERE_FATIGUE -> CriticalRed
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                if (cameraError != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = cameraError!!, color = CriticalRed, fontSize = 11.sp)
                }
            }
        }
    }
}
