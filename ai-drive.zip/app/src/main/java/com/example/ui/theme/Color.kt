package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Claymorphic Dark Automotive Palette
val AutomotiveBackground = Color(0xFF090E1A)

// 3D Soft Clay Surfaces
val ClaySurfaceTop = Color(0xFF19253C)
val ClaySurfaceBottom = Color(0xFF111A2C)
val ClaySurfaceElevatedTop = Color(0xFF223252)
val ClaySurfaceElevatedBottom = Color(0xFF16233B)

val AutomotiveSurface = Color(0xFF111A2C)
val AutomotiveSurfaceVariant = Color(0xFF16233B)
val AutomotiveSurfaceElevated = Color(0xFF1D2C48)
val AutomotiveCardBorder = Color(0x2E00F5FF)

// Dual Shadows & Rims
val ClayHighlightRim = Color(0x38FFFFFF)
val ClayCyanRim = Color(0x5500F5FF)
val ClayDarkShadow = Color(0xB303060C)
val ClayAmbientShadow = Color(0x55000000)

// Vibrant Clay Accents (Pillowy 3D Gradients)
val CyanAccent = Color(0xFF00F5FF)
val TurquoiseAccent = Color(0xFF05D5E8)
val DeepTeal = Color(0xFF0284C7)
val GlowCyan = Color(0x3D00F5FF)

val SafetyGreen = Color(0xFF10E599)
val WarningAmber = Color(0xFFFBBF24)
val CriticalRed = Color(0xFFFF4757)
val InfoBlue = Color(0xFF38BDF8)

// Typography & Content
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextOnCyan = Color(0xFF04121E)
