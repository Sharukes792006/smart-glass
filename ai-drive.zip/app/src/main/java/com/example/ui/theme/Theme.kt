package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkAutomotiveColorScheme = darkColorScheme(
    primary = CyanAccent,
    onPrimary = TextOnCyan,
    primaryContainer = Color(0xFF0C384D),
    onPrimaryContainer = CyanAccent,
    secondary = TurquoiseAccent,
    onSecondary = Color(0xFF041924),
    secondaryContainer = Color(0xFF0A2B3D),
    onSecondaryContainer = TurquoiseAccent,
    tertiary = SafetyGreen,
    onTertiary = Color(0xFF022013),
    background = AutomotiveBackground,
    onBackground = TextPrimary,
    surface = AutomotiveSurface,
    onSurface = TextPrimary,
    surfaceVariant = AutomotiveSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = AutomotiveCardBorder,
    error = CriticalRed,
    onError = Color.White
)

@Composable
fun AIDriveTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkAutomotiveColorScheme,
        typography = Typography,
        content = content
    )
}
