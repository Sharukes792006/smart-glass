package com.example.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.BleConnectionState
import com.example.models.BleGlassesState
import com.example.models.GlassesBleConstants
import com.example.ui.ClayButton
import com.example.ui.ClayCard
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.ClayHighlightRim
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent

@Composable
fun GlassesBleScreen(
    bleState: BleGlassesState,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit,
    onDisconnect: () -> Unit
) {
    var serviceUuid by remember { mutableStateOf(GlassesBleConstants.DEFAULT_SERVICE_UUID) }
    var telemetryCharUuid by remember { mutableStateOf(GlassesBleConstants.TELEMETRY_CHAR_UUID) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .padding(horizontal = 20.dp)
            .testTag("glasses_ble_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Column {
                Text(
                    text = "ESP32-S3 GLASSES",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        letterSpacing = 2.sp
                    )
                )
                Text(
                    text = "Bluetooth Low Energy & Sensors",
                    style = MaterialTheme.typography.bodySmall.copy(color = TurquoiseAccent)
                )
            }
        }

        // Connection Status Card
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth().testTag("ble_status_card"),
                shape = RoundedCornerShape(26.dp),
                isElevated = true,
                rimColor = if (bleState.isHardwareConnected) SafetyGreen.copy(alpha = 0.6f) else ClayHighlightRim
            ) {
                Column(modifier = Modifier.padding(22.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (bleState.isHardwareConnected) SafetyGreen.copy(alpha = 0.16f)
                                        else Color(0x1A00F5FF)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (bleState.connectionState == BleConnectionState.SCANNING)
                                        Icons.Default.BluetoothSearching else Icons.Default.Bluetooth,
                                    contentDescription = "Bluetooth",
                                    tint = if (bleState.isHardwareConnected) SafetyGreen else CyanAccent,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (bleState.isHardwareConnected) (bleState.deviceName ?: "ESP32-S3 Glasses")
                                    else "Hardware Offline",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (bleState.isHardwareConnected) SafetyGreen else TextPrimary
                                    )
                                )
                                Text(
                                    text = bleState.statusMessage,
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                                )
                            }
                        }

                        if (bleState.connectionState == BleConnectionState.SCANNING) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = CyanAccent,
                                strokeWidth = 2.5.dp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    if (bleState.isHardwareConnected) {
                        ClayButton(
                            text = "Disconnect Glasses",
                            onClick = onDisconnect,
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("ble_disconnect_button"),
                            gradientColors = listOf(Color(0xFFFF5E7E), Color(0xFFD91E48)),
                            textColor = Color.White
                        )
                    } else {
                        if (bleState.connectionState == BleConnectionState.SCANNING) {
                            ClayButton(
                                text = "Cancel Scan",
                                onClick = onStopScan,
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("ble_stop_scan_button"),
                                gradientColors = listOf(Color(0xFF2A374A), Color(0xFF1B2433)),
                                textColor = TextSecondary
                            )
                        } else {
                            ClayButton(
                                text = "Scan for ESP32-S3 Glasses",
                                icon = Icons.Default.Refresh,
                                onClick = onStartScan,
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("ble_start_scan_button"),
                                gradientColors = listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                                textColor = TextOnCyan
                            )
                        }
                    }
                }
            }
        }

        // Subsystems (Clean, friendly)
        item {
            Text(
                text = "SENSOR MODULES",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.2.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
            )
            Spacer(modifier = Modifier.height(4.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SensorRowItem(
                    name = "OV2640 Eye Tracker Camera",
                    desc = "Blink rate & PERCLOS eye-closure monitoring",
                    online = bleState.ov2640CameraOnline,
                    icon = Icons.Default.CameraAlt
                )
                SensorRowItem(
                    name = "MPU6050 6-Axis IMU",
                    desc = "Head tilt, nodding, and road gaze orientation",
                    online = bleState.mpu6050ImuOnline,
                    icon = Icons.Default.Face
                )
                SensorRowItem(
                    name = "MQ-3 Breath Alcohol Sensor",
                    desc = "Vapor concentration circuit ADC stream",
                    online = bleState.mq3AlcoholSensorOnline,
                    icon = Icons.Default.LocalDrink
                )
            }
        }

        // GATT UUID settings (Clean & minimal)
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth().testTag("ble_config_card"),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "GATT CONFIGURATION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = serviceUuid,
                        onValueChange = { serviceUuid = it },
                        label = { Text("Service UUID") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = Color(0x25FFFFFF),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = telemetryCharUuid,
                        onValueChange = { telemetryCharUuid = it },
                        label = { Text("Telemetry UUID") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = Color(0x25FFFFFF),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SensorRowItem(name: String, desc: String, online: Boolean, icon: ImageVector) {
    ClayCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (online) SafetyGreen.copy(alpha = 0.16f) else Color(0x15FFFFFF)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (online) SafetyGreen else TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary))
                Text(text = desc, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp))
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (online) SafetyGreen.copy(alpha = 0.16f) else Color(0x15FFFFFF))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = if (online) "STREAMING" else "STANDBY",
                    color = if (online) SafetyGreen else TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
