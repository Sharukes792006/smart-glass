package com.example.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.AlertSeverity
import com.example.models.BleGlassesState
import com.example.models.DrowsinessLevel
import com.example.models.SafetyAlert
import com.example.models.SafetyScore
import com.example.models.TelemetryData
import com.example.services.ActiveTripState
import com.example.ui.ClayButton
import com.example.ui.ClayCard
import com.example.ui.ClayDemoCapsule
import com.example.ui.ClayGlassesPill
import com.example.ui.ClayScoreOrb
import com.example.ui.ClaySensorTile
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.ClayCyanRim
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.WarningAmber

@Composable
fun DashboardScreen(
    telemetry: TelemetryData,
    safetyScore: SafetyScore,
    bleState: BleGlassesState,
    activeTrip: ActiveTripState,
    recentAlerts: List<SafetyAlert>,
    onNavigateToLiveMonitoring: () -> Unit,
    onNavigateToGlassesBle: () -> Unit,
    onNavigateToEmergencySos: () -> Unit,
    onNavigateToTrips: () -> Unit,
    onStartTrip: () -> Unit,
    onStopTrip: () -> Unit,
    onAcknowledgeAlert: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .padding(horizontal = 20.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Minimal Header with Glasses Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI DRIVE",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            letterSpacing = 2.sp
                        )
                    )
                    Text(
                        text = "Smart Safety Cockpit",
                        style = MaterialTheme.typography.bodySmall.copy(color = TurquoiseAccent)
                    )
                }

                ClayGlassesPill(
                    bleState = bleState,
                    onClick = onNavigateToGlassesBle
                )
            }
        }

        // Demo Mode Pill
        item {
            ClayDemoCapsule(
                onScenarioClick = onNavigateToLiveMonitoring
            )
        }

        // Big Claymorphic Score Orb in Center
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth().testTag("safety_score_card"),
                shape = RoundedCornerShape(32.dp),
                isElevated = true,
                rimColor = ClayCyanRim
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp, horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ClayScoreOrb(safetyScore = safetyScore)

                    Spacer(modifier = Modifier.height(18.dp))

                    // Minimal 4 status dots
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ScoreStatChip("Fatigue", safetyScore.fatiguePenalty == 0)
                        ScoreStatChip("Gaze", safetyScore.distractionPenalty == 0)
                        ScoreStatChip("Posture", safetyScore.headMovementPenalty == 0)
                        ScoreStatChip("Alcohol", safetyScore.alcoholPenalty == 0)
                    }
                }
            }
        }

        // Tactile Action Row: Emergency SOS & Drive Recorder
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ClayButton(
                    text = "EMERGENCY SOS",
                    icon = Icons.Default.Emergency,
                    onClick = onNavigateToEmergencySos,
                    modifier = Modifier.weight(1f).height(54.dp).testTag("sos_dashboard_shortcut_button"),
                    gradientColors = listOf(Color(0xFFFF5E7E), Color(0xFFD91E48)),
                    textColor = Color.White
                )

                ClayButton(
                    text = if (activeTrip.isRunning) "End Drive" else "Start Drive",
                    icon = if (activeTrip.isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    onClick = {
                        if (activeTrip.isRunning) onStopTrip() else onStartTrip()
                    },
                    modifier = Modifier.weight(1f).height(54.dp).testTag("toggle_trip_button"),
                    gradientColors = if (activeTrip.isRunning) listOf(Color(0xFFFFA502), Color(0xFFFF6348))
                    else listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                    textColor = TextOnCyan
                )
            }
        }

        // Live Trip HUD Pill if running
        if (activeTrip.isRunning) {
            item {
                ClayCard(
                    modifier = Modifier.fillMaxWidth().testTag("active_trip_card"),
                    shape = RoundedCornerShape(20.dp),
                    rimColor = SafetyGreen.copy(alpha = 0.5f),
                    onClick = onNavigateToTrips
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(SafetyGreen)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "RECORDING DRIVE",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SafetyGreen,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                )
                                val mins = activeTrip.durationSeconds / 60
                                val secs = activeTrip.durationSeconds % 60
                                Text(
                                    text = "${mins}m ${secs}s • ${"%.1f".format(activeTrip.distanceKm)} km • ${activeTrip.currentSpeedKmh.toInt()} km/h",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                )
                            }
                        }

                        Text(
                            text = "Score: ${activeTrip.averageScore}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = CyanAccent,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // 2 Big User-Friendly Clay Sensor Tiles (Low clutter, high clarity)
        item {
            Text(
                text = "TELEMETRY METRICS",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.2.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
            )
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Eye Tracking DMS
                val fatigueColor = when (telemetry.drowsinessLevel) {
                    DrowsinessLevel.ALERT -> SafetyGreen
                    DrowsinessLevel.MILD_FATIGUE -> WarningAmber
                    DrowsinessLevel.SEVERE_FATIGUE -> CriticalRed
                }
                ClaySensorTile(
                    title = "Eye & Attention",
                    value = "${"%.1f".format(telemetry.eyeClosurePerclos)}%",
                    statusText = telemetry.drowsinessLevel.name.replace("_", " "),
                    icon = Icons.Default.RemoveRedEye,
                    accentColor = fatigueColor,
                    progress = telemetry.eyeClosurePerclos / 100f,
                    alertActive = telemetry.drowsinessLevel == DrowsinessLevel.SEVERE_FATIGUE,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToLiveMonitoring
                )

                // Alcohol & Posture
                val alcColor = when (telemetry.alcoholState) {
                    com.example.models.AlcoholState.CLEAR -> SafetyGreen
                    com.example.models.AlcoholState.TRACE -> TurquoiseAccent
                    com.example.models.AlcoholState.WARNING -> WarningAmber
                    com.example.models.AlcoholState.DANGER -> CriticalRed
                    com.example.models.AlcoholState.SENSOR_WARMING_UP -> TextMuted
                }
                ClaySensorTile(
                    title = "MQ-3 Alcohol",
                    value = "${"%.2f".format(telemetry.alcoholMgL)}",
                    statusText = telemetry.alcoholState.name,
                    icon = Icons.Default.LocalDrink,
                    accentColor = alcColor,
                    alertActive = telemetry.alcoholMgL >= 0.05f,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToLiveMonitoring
                )
            }
        }

        // Recent Safety Alerts (Clean & decluttered)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SAFETY ALERTS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        letterSpacing = 1.2.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                )
                Text(
                    text = "${recentAlerts.count { !it.acknowledged }} Active",
                    style = MaterialTheme.typography.labelSmall.copy(color = CyanAccent)
                )
            }
        }

        if (recentAlerts.isEmpty()) {
            item {
                ClayCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text(
                        text = "Everything clear. Safe driving!",
                        modifier = Modifier.padding(18.dp),
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        } else {
            items(recentAlerts.take(2)) { alert ->
                ClayAlertItem(
                    alert = alert,
                    onAcknowledge = { onAcknowledgeAlert(alert.id) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(18.dp))
        }
    }
}

@Composable
private fun ScoreStatChip(name: String, isOk: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (isOk) SafetyGreen else CriticalRed)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

@Composable
fun ClayAlertItem(
    alert: SafetyAlert,
    onAcknowledge: () -> Unit
) {
    val borderColor = when (alert.severity) {
        AlertSeverity.CRITICAL -> CriticalRed
        AlertSeverity.WARNING -> WarningAmber
        AlertSeverity.INFO -> TurquoiseAccent
    }

    ClayCard(
        modifier = Modifier.fillMaxWidth().testTag("safety_alert_${alert.id}"),
        shape = RoundedCornerShape(18.dp),
        rimColor = borderColor.copy(alpha = 0.5f)
    ) {
        Row(
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = alert.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 14.sp
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = alert.message,
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                )
            }

            if (!alert.acknowledged) {
                IconButton(
                    onClick = onAcknowledge,
                    modifier = Modifier.testTag("ack_button_${alert.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Acknowledge",
                        tint = CyanAccent
                    )
                }
            }
        }
    }
}
