package com.example.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.SimulationScenario
import com.example.models.TelemetryData
import com.example.services.SimulationState
import com.example.services.camera.CameraDmsManager
import com.example.ui.CameraDmsPreviewCard
import com.example.ui.ClayButton
import com.example.ui.ClayCard
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.ClayCyanRim
import com.example.ui.theme.ClayHighlightRim
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.WarningAmber

@Composable
fun LiveMonitoringScreen(
    telemetry: TelemetryData,
    simState: SimulationState,
    activeScenario: SimulationScenario,
    cameraManager: CameraDmsManager,
    isCameraModeActive: Boolean,
    onToggleCameraMode: (Boolean) -> Unit,
    onStartSimulation: (SimulationScenario) -> Unit,
    onPauseSimulation: () -> Unit,
    onResumeSimulation: () -> Unit,
    onStopSimulation: () -> Unit,
    onSelectScenario: (SimulationScenario) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .padding(horizontal = 20.dp)
            .testTag("live_monitoring_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // CameraX Real-time Video Stream Card
        item {
            Spacer(modifier = Modifier.height(4.dp))
            CameraDmsPreviewCard(
                cameraManager = cameraManager,
                isCameraModeActive = isCameraModeActive,
                onToggleCameraMode = onToggleCameraMode
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIVE SIMULATION",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            letterSpacing = 2.sp
                        )
                    )
                    Text(
                        text = "DMS Telemetry Test Bench",
                        style = MaterialTheme.typography.bodySmall.copy(color = TurquoiseAccent)
                    )
                }

                val stateColor = when (simState) {
                    SimulationState.RUNNING -> SafetyGreen
                    SimulationState.PAUSED -> WarningAmber
                    SimulationState.STOPPED -> TextMuted
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(stateColor.copy(alpha = 0.16f))
                        .border(1.dp, stateColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = simState.name,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = stateColor
                        )
                    )
                }
            }
        }

        // Tactile Control Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (simState) {
                    SimulationState.STOPPED -> {
                        ClayButton(
                            text = "Start Simulation",
                            icon = Icons.Default.PlayArrow,
                            onClick = { onStartSimulation(activeScenario) },
                            modifier = Modifier.weight(1f).height(50.dp).testTag("sim_start_button"),
                            gradientColors = listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                            textColor = TextOnCyan
                        )
                    }
                    SimulationState.RUNNING -> {
                        ClayButton(
                            text = "Pause",
                            icon = Icons.Default.Pause,
                            onClick = onPauseSimulation,
                            modifier = Modifier.weight(1f).height(50.dp).testTag("sim_pause_button"),
                            gradientColors = listOf(Color(0xFFFBBF24), Color(0xFFD97706)),
                            textColor = TextOnCyan
                        )
                    }
                    SimulationState.PAUSED -> {
                        ClayButton(
                            text = "Resume",
                            icon = Icons.Default.PlayArrow,
                            onClick = onResumeSimulation,
                            modifier = Modifier.weight(1f).height(50.dp).testTag("sim_resume_button"),
                            gradientColors = listOf(Color(0xFF10E599), Color(0xFF059669)),
                            textColor = TextOnCyan
                        )
                    }
                }

                if (simState != SimulationState.STOPPED) {
                    ClayButton(
                        text = "Stop",
                        icon = Icons.Default.Stop,
                        onClick = onStopSimulation,
                        modifier = Modifier.weight(1f).height(50.dp).testTag("sim_stop_button"),
                        gradientColors = listOf(Color(0xFFFF5E7E), Color(0xFFD91E48)),
                        textColor = Color.White
                    )
                }
            }
        }

        // Key Live Telemetry Pill Card
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth().testTag("telemetry_stream_card"),
                shape = RoundedCornerShape(26.dp),
                isElevated = true,
                rimColor = ClayCyanRim
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "ACTIVE TELEMETRY STREAM",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ClayMetricCol("PERCLOS Eye", "${"%.1f".format(telemetry.eyeClosurePerclos)}%", CyanAccent)
                        ClayMetricCol("Blink ms", "${telemetry.blinkDurationMs}", TurquoiseAccent)
                        ClayMetricCol("Off-Road Gaze", "${"%.1f".format(telemetry.gazeOffRoadSeconds)}s", if (telemetry.gazeOffRoadSeconds > 2f) CriticalRed else SafetyGreen)
                        ClayMetricCol("MQ-3 Alcohol", "${"%.2f".format(telemetry.alcoholMgL)}", if (telemetry.alcoholMgL > 0.05f) CriticalRed else SafetyGreen)
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x20000000))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "Status: ${telemetry.drowsinessLevel.name} • Head Pitch: ${telemetry.pitchDeg.toInt()}° • Head Roll: ${telemetry.rollDeg.toInt()}°",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                        )
                    }
                }
            }
        }

        // Scenario Selector (Touch-friendly clay cards)
        item {
            Text(
                text = "SELECT SCENARIO",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.2.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
            )
            Spacer(modifier = Modifier.height(4.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SimulationScenario.values().forEach { scenario ->
                    val isSelected = scenario == activeScenario
                    ClayCard(
                        modifier = Modifier.fillMaxWidth().testTag("scenario_chip_${scenario.name}"),
                        shape = RoundedCornerShape(20.dp),
                        isElevated = isSelected,
                        rimColor = if (isSelected) CyanAccent else ClayHighlightRim,
                        onClick = { onSelectScenario(scenario) }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = scenario.displayName,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = if (isSelected) CyanAccent else TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = scenario.description,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(CyanAccent)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Disclaimer
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Notice",
                        tint = TurquoiseAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Demo Bench: Values are generated locally for algorithm testing. Not certified medical or law enforcement measurements.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun ClayMetricCol(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = color,
                fontSize = 16.sp
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextSecondary,
                fontSize = 10.sp
            )
        )
    }
}
