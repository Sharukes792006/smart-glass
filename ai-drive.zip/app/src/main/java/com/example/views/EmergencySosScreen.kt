package com.example.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.models.EmergencyContact
import com.example.services.SosUiState
import com.example.ui.ClayButton
import com.example.ui.ClayCard
import com.example.ui.EmergencySosModal
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.ClayAmbientShadow
import com.example.ui.theme.ClayDarkShadow
import com.example.ui.theme.ClayHighlightRim
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.WarningAmber

@Composable
fun EmergencySosScreen(
    sosState: SosUiState,
    contacts: List<EmergencyContact>,
    onTriggerCountdown: () -> Unit,
    onTriggerImmediate: () -> Unit,
    onCancelSos: () -> Unit,
    onDialNumber: (String) -> Unit,
    onSendSms: (String, String, String) -> Unit,
    onDismissSos: () -> Unit,
    onAddContact: (String, String, String, Boolean) -> Unit,
    onDeleteContact: (String) -> Unit,
    onNavigateToConfig: () -> Unit = {},
    onNavigateToEvent: () -> Unit = {},
    onRunTestEmergency: () -> Unit = {}
) {
    var showAddContactDialog by remember { mutableStateOf(false) }
    var contactName by remember { mutableStateOf("") }
    var contactPhone by remember { mutableStateOf("") }
    var contactRelation by remember { mutableStateOf("") }
    var isPrimaryContact by remember { mutableStateOf(false) }

    EmergencySosModal(
        sosState = sosState,
        onCancel = onCancelSos,
        onDial = onDialNumber,
        onSendSms = onSendSms,
        onDismiss = onDismissSos
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .padding(horizontal = 20.dp)
            .testTag("emergency_sos_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "EMERGENCY & CONTACTS",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = CriticalRed,
                            letterSpacing = 2.sp
                        )
                    )
                    Text(
                        text = "Safety Dispatch & Contact Sequence",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                }

                ClayButton(
                    text = "Config",
                    onClick = onNavigateToConfig,
                    gradientColors = listOf(Color(0xFF2A3952), Color(0xFF192335)),
                    textColor = CyanAccent
                )
            }
        }

        // Test Workflow & Event Console Shortcuts
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ClayButton(
                    text = "Test Workflow (Safe)",
                    onClick = onRunTestEmergency,
                    modifier = Modifier.weight(1f).height(44.dp),
                    gradientColors = listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                    textColor = Color(0xFF04121E)
                )

                ClayButton(
                    text = "Event Console",
                    onClick = onNavigateToEvent,
                    modifier = Modifier.weight(1f).height(44.dp),
                    gradientColors = listOf(Color(0xFF2A3952), Color(0xFF192335)),
                    textColor = TextPrimary
                )
            }
        }

        // Giant 3D Clay SOS Panic Orb
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth().testTag("emergency_trigger_card"),
                shape = RoundedCornerShape(32.dp),
                isElevated = true,
                rimColor = CriticalRed.copy(alpha = 0.6f)
            ) {
                Column(
                    modifier = Modifier.padding(26.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .shadow(20.dp, CircleShape, ambientColor = ClayAmbientShadow, spotColor = CriticalRed)
                            .clip(CircleShape)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFFFF5E7E), Color(0xFFD91E48))
                                )
                            )
                            .border(3.dp, Color(0x60FFFFFF), CircleShape)
                            .clickable(onClick = onTriggerCountdown)
                            .testTag("trigger_sos_countdown_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Emergency,
                                contentDescription = "SOS",
                                tint = Color.White,
                                modifier = Modifier.size(52.dp)
                            )
                            Text(
                                text = "SOS",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    letterSpacing = 2.sp
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    Text(
                        text = "Tap for 5s Safety Countdown",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = "Transmits GPS coordinates & alert message to primary emergency contacts.",
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    ClayButton(
                        text = "Immediate SOS (Bypass Countdown)",
                        onClick = onTriggerImmediate,
                        modifier = Modifier.fillMaxWidth().height(46.dp).testTag("immediate_sos_button"),
                        gradientColors = listOf(Color(0xFFFBBF24), Color(0xFFD97706)),
                        textColor = Color(0xFF1E1000)
                    )
                }
            }
        }

        // GPS Geolocation Card
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                rimColor = ClayHighlightRim
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CyanAccent.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "GPS",
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "GPS High-Accuracy Location",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                        )
                        Text(
                            text = "Auto-generates Google Maps links for emergency responders.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                        )
                    }
                }
            }
        }

        // Contacts Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "EMERGENCY CONTACTS (${contacts.size})",
                    style = MaterialTheme.typography.labelSmall.copy(
                        letterSpacing = 1.2.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                )
                TextButton(
                    onClick = { showAddContactDialog = true },
                    modifier = Modifier.testTag("add_contact_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Contact", color = CyanAccent, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (contacts.isEmpty()) {
            item {
                ClayCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text(
                        text = "No contacts saved yet.",
                        modifier = Modifier.padding(16.dp),
                        color = TextSecondary
                    )
                }
            }
        } else {
            items(contacts) { contact ->
                ClayCard(
                    modifier = Modifier.fillMaxWidth().testTag("contact_item_${contact.id}"),
                    shape = RoundedCornerShape(18.dp),
                    rimColor = if (contact.isPrimary) CyanAccent.copy(alpha = 0.5f) else ClayHighlightRim
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = contact.name,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                if (contact.isPrimary) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(CyanAccent.copy(alpha = 0.16f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "PRIMARY",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = CyanAccent,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp
                                            )
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${contact.relationship} • ${contact.phone}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }

                        Row {
                            IconButton(onClick = { onDialNumber(contact.phone) }) {
                                Icon(Icons.Default.Phone, contentDescription = "Dial", tint = SafetyGreen)
                            }
                            IconButton(onClick = { onDeleteContact(contact.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showAddContactDialog) {
        Dialog(onDismissRequest = { showAddContactDialog = false }) {
            ClayCard(
                modifier = Modifier.fillMaxWidth().testTag("add_contact_dialog"),
                shape = RoundedCornerShape(26.dp),
                rimColor = CyanAccent
            ) {
                Column(modifier = Modifier.padding(22.dp)) {
                    Text(
                        text = "Add Contact",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = contactName,
                        onValueChange = { contactName = it },
                        label = { Text("Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = Color(0x30FFFFFF),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = contactPhone,
                        onValueChange = { contactPhone = it },
                        label = { Text("Phone Number") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = Color(0x30FFFFFF),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = contactRelation,
                        onValueChange = { contactRelation = it },
                        label = { Text("Relationship") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = Color(0x30FFFFFF),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Primary Contact", color = TextPrimary, fontSize = 14.sp)
                        Switch(
                            checked = isPrimaryContact,
                            onCheckedChange = { isPrimaryContact = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyanAccent,
                                checkedTrackColor = CyanAccent.copy(alpha = 0.3f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showAddContactDialog = false }) {
                            Text("Cancel", color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        ClayButton(
                            text = "Save",
                            onClick = {
                                if (contactName.isNotBlank() && contactPhone.isNotBlank()) {
                                    onAddContact(
                                        contactName,
                                        contactPhone,
                                        contactRelation.ifBlank { "Contact" },
                                        isPrimaryContact
                                    )
                                    contactName = ""
                                    contactPhone = ""
                                    contactRelation = ""
                                    isPrimaryContact = false
                                    showAddContactDialog = false
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
