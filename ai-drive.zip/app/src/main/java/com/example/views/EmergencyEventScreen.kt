package com.example.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.ActionDeliveryStatus
import com.example.models.ContactEmergencyProgress
import com.example.services.SosUiState
import com.example.ui.ClayButton
import com.example.ui.ClayCard
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EmergencyEventScreen(
    sosState: SosUiState,
    onCancelSos: () -> Unit,
    onRetryEmergency: () -> Unit,
    onDismiss: () -> Unit,
    onManualDial: (String) -> Unit,
    onManualSms: (String, String) -> Unit
) {
    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .padding(horizontal = 20.dp)
            .testTag("emergency_event_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "EMERGENCY EVENT CONSOLE",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = CriticalRed,
                            letterSpacing = 1.5.sp
                        )
                    )
                    Text(
                        text = "Real-Time Dispatch & Telemetry Monitor",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }
        }

        when (sosState) {
            is SosUiState.CountingDown -> {
                item {
                    ClayCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(28.dp),
                        isElevated = true,
                        rimColor = CriticalRed
                    ) {
                        Column(
                            modifier = Modifier.padding(26.dp).fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "CRITICAL DISTRESS DETECTED",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = CriticalRed,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.5.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = sosState.reason,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Box(
                                modifier = Modifier
                                    .size(110.dp)
                                    .clip(CircleShape)
                                    .background(CriticalRed)
                                    .border(3.dp, Color(0x60FFFFFF), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${sosState.secondsRemaining}",
                                    style = MaterialTheme.typography.displayLarge.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 54.sp
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(18.dp))
                            Text(
                                text = "Automated dispatch will transmit GPS location to emergency contacts.",
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                            Spacer(modifier = Modifier.height(20.dp))

                            ClayButton(
                                text = "CANCEL EMERGENCY — FALSE ALARM",
                                onClick = onCancelSos,
                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                gradientColors = listOf(Color(0xFF2A3952), Color(0xFF192335)),
                                textColor = TextPrimary
                            )
                        }
                    }
                }
            }

            is SosUiState.Executing -> {
                item {
                    ClayCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(26.dp),
                        isElevated = true,
                        rimColor = CriticalRed
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = CriticalRed,
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (sosState.isTestMode) "EXECUTING TEST SIMULATION" else "DISPATCHING LIVE EMERGENCY",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = CriticalRed,
                                            fontSize = 14.sp
                                        )
                                    )
                                    Text(
                                        text = "GPS Acquired: ${sosState.locationUrl}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = CyanAccent, fontSize = 11.sp)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "CONTACT ACTION PROGRESS",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontWeight = FontWeight.Bold)
                    )
                }

                items(sosState.progressList) { item ->
                    ContactProgressItem(item = item, onManualDial = onManualDial)
                }
            }

            is SosUiState.Completed -> {
                item {
                    ClayCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(26.dp),
                        isElevated = true,
                        rimColor = SafetyGreen
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SafetyGreen, modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "EMERGENCY SEQUENCE COMPLETE",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = SafetyGreen
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = sosState.summary,
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Timestamp: ${timeFormat.format(Date(sosState.event.timestamp))}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                            )
                        }
                    }
                }

                item {
                    Text(
                        text = "DELIVERY & CALL OUTCOMES",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontWeight = FontWeight.Bold)
                    )
                }

                items(sosState.progressList) { item ->
                    ContactProgressItem(item = item, onManualDial = onManualDial)
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ClayButton(
                            text = "Retry Dispatch",
                            icon = Icons.Default.Refresh,
                            onClick = onRetryEmergency,
                            modifier = Modifier.weight(1f).height(46.dp),
                            gradientColors = listOf(Color(0xFFFF5E7E), Color(0xFFD91E48)),
                            textColor = Color.White
                        )
                        ClayButton(
                            text = "Dismiss Event",
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f).height(46.dp),
                            gradientColors = listOf(Color(0xFF2A3952), Color(0xFF192335)),
                            textColor = TextPrimary
                        )
                    }
                }
            }

            else -> {
                item {
                    ClayCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                        Column(
                            modifier = Modifier.padding(24.dp).fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "No active emergency event in progress.", color = TextSecondary)
                            Spacer(modifier = Modifier.height(14.dp))
                            ClayButton(
                                text = "Run Test Emergency Event",
                                onClick = onRetryEmergency
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun ContactProgressItem(
    item: ContactEmergencyProgress,
    onManualDial: (String) -> Unit
) {
    ClayCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = item.contact.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                    )
                    Text(
                        text = "${item.contact.relationship} • ${item.contact.phone}",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                }

                IconButton(onClick = { onManualDial(item.contact.phone) }) {
                    Icon(Icons.Default.Phone, contentDescription = "Call", tint = SafetyGreen)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                DeliveryPill("SMS", item.smsStatus)
                DeliveryPill("CALL", item.callStatus)
            }
        }
    }
}

@Composable
private fun DeliveryPill(type: String, status: ActionDeliveryStatus) {
    val (text, color) = when (status) {
        ActionDeliveryStatus.SENT_DIRECT -> "Direct Sent (SmsManager)" to SafetyGreen
        ActionDeliveryStatus.INITIATED_CALL -> "Direct Initiated (CALL)" to SafetyGreen
        ActionDeliveryStatus.FALLBACK_COMPOSER -> "Opened Composer Fallback" to CyanAccent
        ActionDeliveryStatus.FALLBACK_DIALER -> "Opened Dialer Fallback" to CyanAccent
        ActionDeliveryStatus.SIMULATED_SUCCESS -> "Simulated (Test Mode)" to TurquoiseAccent
        ActionDeliveryStatus.PENDING, ActionDeliveryStatus.SENDING -> "Processing..." to WarningAmber
        ActionDeliveryStatus.FAILED -> "Failed" to CriticalRed
        else -> "Standby" to TextMuted
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = "$type: $text",
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp
        )
    }
}
