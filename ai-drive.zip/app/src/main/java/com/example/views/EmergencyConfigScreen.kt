package com.example.views

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.EmergencyConfig
import com.example.ui.ClayButton
import com.example.ui.ClayCard
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.WarningAmber

@Composable
fun EmergencyConfigScreen(
    config: EmergencyConfig,
    hasSendSmsPermission: Boolean,
    hasCallPhonePermission: Boolean,
    hasGpsPermission: Boolean,
    onUpdateConfig: (EmergencyConfig) -> Unit,
    onTestSimulation: () -> Unit
) {
    var templateText by remember(config.smsTemplate) { mutableStateOf(config.smsTemplate) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Updated permissions state handled automatically by ViewModel/Service
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .padding(horizontal = 20.dp)
            .testTag("emergency_config_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Column {
                Text(
                    text = "EMERGENCY CONFIGURATION",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = CriticalRed,
                        letterSpacing = 2.sp
                    )
                )
                Text(
                    text = "Automation, Consent & Permissions",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
            }
        }

        // Test Simulation Mode Banner (Safe Sandbox)
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                isElevated = true,
                rimColor = if (config.isTestSimulationMode) SafetyGreen.copy(alpha = 0.6f) else WarningAmber
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TEST SIMULATION MODE",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (config.isTestSimulationMode) SafetyGreen else WarningAmber,
                                    fontSize = 14.sp
                                )
                            )
                            Text(
                                text = if (config.isTestSimulationMode) "Safe mode active: runs complete sequence without transmitting real SMS or phone calls."
                                else "Live mode: will attempt actual SMS/calls if permissions and consent are granted.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                            )
                        }

                        Switch(
                            checked = config.isTestSimulationMode,
                            onCheckedChange = { checked ->
                                onUpdateConfig(config.copy(isTestSimulationMode = checked))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SafetyGreen,
                                checkedTrackColor = SafetyGreen.copy(alpha = 0.3f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    ClayButton(
                        text = "Run Simulation Test Now",
                        icon = Icons.Default.PlayArrow,
                        onClick = onTestSimulation,
                        modifier = Modifier.fillMaxWidth().height(44.dp).testTag("test_simulation_button"),
                        gradientColors = listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                        textColor = TextOnCyan
                    )
                }
            }
        }

        // Explicit Informed Consent Card
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                rimColor = if (config.userConsentGranted) CyanAccent else CriticalRed.copy(alpha = 0.6f)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "DRIVER INFORMED CONSENT",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontSize = 14.sp
                                )
                            )
                            Text(
                                text = "Explicit permission to trigger automatic emergency dispatch when sustained severe driver fatigue or crashes are confirmed.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                            )
                        }

                        Switch(
                            checked = config.userConsentGranted,
                            onCheckedChange = { granted ->
                                onUpdateConfig(
                                    config.copy(
                                        userConsentGranted = granted,
                                        autoAssistanceEnabled = if (!granted) false else config.autoAssistanceEnabled
                                    )
                                )
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyanAccent,
                                checkedTrackColor = CyanAccent.copy(alpha = 0.3f)
                            )
                        )
                    }

                    if (!config.userConsentGranted) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "⚠ Automated emergency actions are blocked until consent is acknowledged.",
                            color = WarningAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Automation Toggle & Countdown Configuration
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "AUTOMATIC EMERGENCY DISPATCH",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontSize = 14.sp
                                )
                            )
                            Text(
                                text = "Start automated cancellation timer upon sustained critical alerts.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                            )
                        }

                        Switch(
                            checked = config.autoAssistanceEnabled && config.userConsentGranted,
                            onCheckedChange = { enabled ->
                                if (config.userConsentGranted) {
                                    onUpdateConfig(config.copy(autoAssistanceEnabled = enabled))
                                }
                            },
                            enabled = config.userConsentGranted,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CriticalRed,
                                checkedTrackColor = CriticalRed.copy(alpha = 0.3f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Cancellation Countdown Duration:",
                        style = MaterialTheme.typography.labelSmall.copy(color = CyanAccent, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 10, 15).forEach { sec ->
                            val isSelected = config.countdownDurationSeconds == sec
                            FilterChip(
                                selected = isSelected,
                                onClick = { onUpdateConfig(config.copy(countdownDurationSeconds = sec)) },
                                label = { Text("${sec}s Countdown", fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanAccent,
                                    selectedLabelColor = Color(0xFF04121E)
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Include Live GPS Location Link",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary)
                        )
                        Switch(
                            checked = config.includeGpsLocation,
                            onCheckedChange = { checked ->
                                onUpdateConfig(config.copy(includeGpsLocation = checked))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyanAccent,
                                checkedTrackColor = CyanAccent.copy(alpha = 0.3f)
                            )
                        )
                    }
                }
            }
        }

        // SMS Template Customizer
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "EMERGENCY SMS TEMPLATE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = templateText,
                        onValueChange = {
                            templateText = it
                            onUpdateConfig(config.copy(smsTemplate = it))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = Color(0x25FFFFFF),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Live GPS Google Maps URL and critical reason will be appended automatically.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                    )
                }
            }
        }

        // Runtime Permissions Inspector
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ANDROID OS PERMISSIONS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanAccent
                            )
                        )

                        ClayButton(
                            text = "Grant",
                            onClick = {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.SEND_SMS,
                                        Manifest.permission.CALL_PHONE,
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                    )
                                )
                            }
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    PermissionStatusRow("SEND_SMS (Direct SMS via SmsManager)", hasSendSmsPermission)
                    PermissionStatusRow("CALL_PHONE (Direct Call vs Dialer Fallback)", hasCallPhonePermission)
                    PermissionStatusRow("ACCESS_FINE_LOCATION (Accurate GPS)", hasGpsPermission)
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun PermissionStatusRow(name: String, granted: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = name, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (granted) SafetyGreen.copy(alpha = 0.16f) else WarningAmber.copy(alpha = 0.16f))
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = if (granted) "GRANTED" else "NOT GRANTED",
                color = if (granted) SafetyGreen else WarningAmber,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }
    }
}
