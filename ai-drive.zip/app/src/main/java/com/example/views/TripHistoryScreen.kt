package com.example.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.Trip
import com.example.services.ActiveTripState
import com.example.ui.ClayButton
import com.example.ui.ClayCard
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.ClayHighlightRim
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextOnCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TripHistoryScreen(
    trips: List<Trip>,
    activeTrip: ActiveTripState,
    onStartTrip: () -> Unit,
    onStopTrip: () -> Unit
) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.US)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .padding(horizontal = 20.dp)
            .testTag("trip_history_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TRIP LOGS",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            letterSpacing = 2.sp
                        )
                    )
                    Text(
                        text = "Driving Safety Records",
                        style = MaterialTheme.typography.bodySmall.copy(color = TurquoiseAccent)
                    )
                }

                ClayButton(
                    text = if (activeTrip.isRunning) "End" else "Start",
                    icon = if (activeTrip.isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    onClick = {
                        if (activeTrip.isRunning) onStopTrip() else onStartTrip()
                    },
                    modifier = Modifier.testTag("trip_toggle_button"),
                    gradientColors = if (activeTrip.isRunning) listOf(Color(0xFFFF5E7E), Color(0xFFD91E48))
                    else listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                    textColor = if (activeTrip.isRunning) Color.White else TextOnCyan
                )
            }
        }

        // Live Drive Card
        if (activeTrip.isRunning) {
            item {
                ClayCard(
                    modifier = Modifier.fillMaxWidth().testTag("live_trip_card"),
                    shape = RoundedCornerShape(24.dp),
                    isElevated = true,
                    rimColor = SafetyGreen.copy(alpha = 0.6f)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(SafetyGreen)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "DRIVE RECORDING",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SafetyGreen,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                )
                            }
                            Text(
                                text = "Score: ${activeTrip.averageScore}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CyanAccent
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        val mins = activeTrip.durationSeconds / 60
                        val secs = activeTrip.durationSeconds % 60
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TripStatItem("Duration", "${mins}m ${secs}s")
                            TripStatItem("Distance", "${"%.1f".format(activeTrip.distanceKm)} km")
                            TripStatItem("Speed", "${activeTrip.currentSpeedKmh.toInt()} km/h")
                            TripStatItem("Infractions", "${activeTrip.fatigueCount}")
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "SAVED DRIVES (${trips.size})",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.2.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
            )
        }

        if (trips.isEmpty()) {
            item {
                ClayCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Text(
                        text = "No trips recorded yet. Tap Start to log a drive.",
                        modifier = Modifier.padding(18.dp),
                        color = TextSecondary
                    )
                }
            }
        } else {
            items(trips) { trip ->
                val scoreColor = when {
                    trip.safetyScore >= 90 -> CyanAccent
                    trip.safetyScore >= 75 -> SafetyGreen
                    trip.safetyScore >= 50 -> WarningAmber
                    else -> CriticalRed
                }
                val mins = trip.durationSeconds / 60
                val formattedDate = dateFormat.format(Date(trip.startTime))

                ClayCard(
                    modifier = Modifier.fillMaxWidth().testTag("trip_card_${trip.id}"),
                    shape = RoundedCornerShape(20.dp),
                    rimColor = scoreColor.copy(alpha = 0.4f)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${trip.originSummary} → ${trip.destinationSummary}",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        fontSize = 15.sp
                                    )
                                )
                                Text(
                                    text = formattedDate,
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(scoreColor.copy(alpha = 0.15f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${trip.safetyScore}",
                                    color = scoreColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TripStatItem("Duration", "${mins}m")
                            TripStatItem("Distance", "${"%.1f".format(trip.distanceKm)} km")
                            TripStatItem("Avg Speed", "${trip.averageSpeedKmh.toInt()} km/h")
                            TripStatItem("Infractions", "${trip.fatigueEventsCount + trip.distractionEventsCount}")
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun TripStatItem(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 10.sp))
        Text(text = value, style = MaterialTheme.typography.titleMedium.copy(color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp))
    }
}
