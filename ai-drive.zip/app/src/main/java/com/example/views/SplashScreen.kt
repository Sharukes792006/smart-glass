package com.example.views

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.AutomotiveCardBorder
import com.example.ui.theme.AutomotiveSurface
import com.example.ui.theme.AutomotiveSurfaceElevated
import com.example.ui.theme.AutomotiveSurfaceVariant
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onSplashFinished: () -> Unit
) {
    LaunchedEffect(Unit) {
        delay(1400)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(CyanAccent.copy(alpha = 0.25f), Color.Transparent)
                        )
                    )
                    .border(2.dp, CyanAccent, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.RemoveRedEye,
                    contentDescription = "AI Drive Glasses",
                    tint = CyanAccent,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "AI DRIVE",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    letterSpacing = 4.sp
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "SMART DRIVER SAFETY GLASSES",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TurquoiseAccent,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.SemiBold
                )
            )
            Spacer(modifier = Modifier.height(30.dp))
            Text(
                text = "ESP32-S3 TELEMETRY & SOS COCKPIT",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextMuted,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

@Composable
fun OnboardingScreen(
    onFinishOnboarding: () -> Unit,
    onEnterDemoMode: () -> Unit
) {
    var currentStep by remember { mutableIntStateOf(0) }

    val steps = listOf(
        OnboardingStep(
            title = "Intelligent Eye & Fatigue Monitoring",
            subtitle = "ESP32-S3 OV2640 camera micro-optics track real-time eye blink rates, PERCLOS drowsiness percentage, and microsleep risks.",
            icon = Icons.Default.RemoveRedEye,
            accentColor = CyanAccent
        ),
        OnboardingStep(
            title = "MPU6050 Head Motion Tracking",
            subtitle = "6-axis gyroscope and accelerometer detect abnormal head dropping, nodding off, and road distraction vectors instantly.",
            icon = Icons.Default.Speed,
            accentColor = TurquoiseAccent
        ),
        OnboardingStep(
            title = "Experimental Alcohol & Emergency SOS",
            subtitle = "MQ-3 vapor detection alerts combined with automated GPS distress coordinates and one-tap emergency dispatcher contact.",
            icon = Icons.Default.Emergency,
            accentColor = SafetyGreen
        )
    )

    val step = steps[currentStep]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .padding(24.dp)
            .testTag("onboarding_screen"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "AI DRIVE HUD",
                style = MaterialTheme.typography.labelLarge.copy(
                    color = CyanAccent,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
            )
            OutlinedButton(
                onClick = onEnterDemoMode,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, AutomotiveCardBorder),
                modifier = Modifier.testTag("skip_to_demo_button")
            ) {
                Text("Demo Mode", color = TextSecondary, fontSize = 12.sp)
            }
        }

        // Center Step Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(step.accentColor.copy(alpha = 0.12f))
                    .border(2.dp, step.accentColor.copy(alpha = 0.7f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = step.icon,
                    contentDescription = null,
                    tint = step.accentColor,
                    modifier = Modifier.size(54.dp)
                )
            }

            Spacer(modifier = Modifier.height(36.dp))

            Text(
                text = step.title,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = step.subtitle,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = TextSecondary,
                    lineHeight = 24.sp
                )
            )
        }

        // Bottom Controls
        Column(modifier = Modifier.fillMaxWidth()) {
            // Step Dots
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                steps.indices.forEach { index ->
                    Box(
                        modifier = Modifier
                            .padding(4.dp)
                            .height(6.dp)
                            .width(if (index == currentStep) 24.dp else 6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (index == currentStep) CyanAccent else AutomotiveSurfaceVariant)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            com.example.ui.ClayButton(
                text = if (currentStep == steps.size - 1) "Get Started" else "Next",
                icon = Icons.Default.ArrowForward,
                onClick = {
                    if (currentStep < steps.size - 1) {
                        currentStep++
                    } else {
                        onFinishOnboarding()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("onboarding_next_button"),
                gradientColors = listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                textColor = com.example.ui.theme.TextOnCyan
            )
        }
    }
}

private data class OnboardingStep(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accentColor: Color
)
