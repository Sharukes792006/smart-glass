package com.example.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DriveEta
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.DriverProfile
import com.example.ui.ClayButton
import com.example.ui.ClayCard
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SafetyGreen
import com.example.ui.theme.TextOnCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent

@Composable
fun ProfileScreen(
    profile: DriverProfile,
    onUpdateProfile: (DriverProfile) -> Unit,
    onLogout: () -> Unit
) {
    var name by remember(profile) { mutableStateOf(profile.fullName) }
    var vehicle by remember(profile) { mutableStateOf(profile.vehicleModel) }
    var bloodGroup by remember(profile) { mutableStateOf(profile.bloodGroup) }
    var license by remember(profile) { mutableStateOf(profile.driverLicense) }
    var savedSuccess by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AutomotiveBackground)
            .padding(horizontal = 20.dp)
            .testTag("profile_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DRIVER PROFILE",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            letterSpacing = 2.sp
                        )
                    )
                    Text(
                        text = "Vehicle & Safety Credentials",
                        style = MaterialTheme.typography.bodySmall.copy(color = TurquoiseAccent)
                    )
                }

                if (profile.isDemoAccount) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(TurquoiseAccent.copy(alpha = 0.16f))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "DEMO DRIVER",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TurquoiseAccent
                            )
                        )
                    }
                }
            }
        }

        // Tactile Avatar Card
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                isElevated = true
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(CyanAccent.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Avatar",
                            tint = CyanAccent,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = profile.fullName,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 18.sp
                            )
                        )
                        Text(
                            text = profile.email,
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary, fontSize = 12.sp)
                        )
                        Text(
                            text = "Paired: ${profile.glassesPairedName}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TurquoiseAccent, fontSize = 11.sp)
                        )
                    }
                }
            }
        }

        // Credentials Form (Clay Card)
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "VEHICLE & CREDENTIALS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            savedSuccess = false
                        },
                        label = { Text("Driver Name") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = CyanAccent) },
                        modifier = Modifier.fillMaxWidth().testTag("profile_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = Color(0x25FFFFFF),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = vehicle,
                        onValueChange = {
                            vehicle = it
                            savedSuccess = false
                        },
                        label = { Text("Vehicle Model") },
                        leadingIcon = { Icon(Icons.Default.DriveEta, contentDescription = null, tint = CyanAccent) },
                        modifier = Modifier.fillMaxWidth().testTag("profile_vehicle_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = Color(0x25FFFFFF),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = bloodGroup,
                            onValueChange = {
                                bloodGroup = it
                                savedSuccess = false
                            },
                            label = { Text("Blood Group") },
                            leadingIcon = { Icon(Icons.Default.MedicalServices, contentDescription = null, tint = CriticalRed) },
                            modifier = Modifier.weight(1f).testTag("profile_blood_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = Color(0x25FFFFFF),
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = license,
                            onValueChange = {
                                license = it
                                savedSuccess = false
                            },
                            label = { Text("License ID") },
                            modifier = Modifier.weight(1.5f).testTag("profile_license_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = Color(0x25FFFFFF),
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (savedSuccess) {
                        Text(
                            text = "✓ Profile saved",
                            color = SafetyGreen,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    ClayButton(
                        text = "Save Credentials",
                        icon = Icons.Default.Save,
                        onClick = {
                            val updated = profile.copy(
                                fullName = name.trim(),
                                vehicleModel = vehicle.trim(),
                                bloodGroup = bloodGroup.trim(),
                                driverLicense = license.trim()
                            )
                            onUpdateProfile(updated)
                            savedSuccess = true
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_profile_button"),
                        gradientColors = listOf(Color(0xFF33FFFF), Color(0xFF00B4D8)),
                        textColor = TextOnCyan
                    )
                }
            }
        }

        // Logout
        item {
            ClayButton(
                text = "Sign Out / Switch Driver",
                icon = Icons.Default.ExitToApp,
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("profile_logout_button"),
                gradientColors = listOf(Color(0xFF2A374A), Color(0xFF1B2433)),
                textColor = TextSecondary
            )
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
