package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.models.DriverProfile
import com.example.models.EmergencyConfig
import com.example.services.AuthState
import com.example.services.MainViewModel
import com.example.ui.EmergencySosModal
import com.example.ui.theme.AIDriveTheme
import com.example.ui.theme.AutomotiveBackground
import com.example.ui.theme.AutomotiveSurface
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.views.AuthScreen
import com.example.views.DashboardScreen
import com.example.views.EmergencyConfigScreen
import com.example.views.EmergencyEventScreen
import com.example.views.EmergencySosScreen
import com.example.views.GlassesBleScreen
import com.example.views.LiveMonitoringScreen
import com.example.views.OnboardingScreen
import com.example.views.ProfileScreen
import com.example.views.SplashScreen
import com.example.views.TripHistoryScreen
import kotlinx.coroutines.launch

enum class RootNavScreen {
    SPLASH,
    ONBOARDING,
    AUTH,
    MAIN_APP
}

enum class SubScreen {
    NONE,
    EMERGENCY_CONFIG,
    EMERGENCY_EVENT
}

enum class MainAppTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Speed),
    SIMULATION("Live DMS", Icons.Default.Sensors),
    SOS("SOS", Icons.Default.Emergency),
    TRIPS("Trips", Icons.Default.DirectionsCar),
    GLASSES("Glasses", Icons.Default.Bluetooth),
    PROFILE("Profile", Icons.Default.Person)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AIDriveTheme {
                MainAppEntry()
            }
        }
    }
}

@Composable
fun MainAppEntry(
    viewModel: MainViewModel = viewModel()
) {
    var rootScreen by remember { mutableStateOf(RootNavScreen.SPLASH) }
    var currentTab by remember { mutableStateOf(MainAppTab.DASHBOARD) }
    var activeSubScreen by remember { mutableStateOf(SubScreen.NONE) }

    val authState by viewModel.authState.collectAsStateWithLifecycle()
    val telemetry by viewModel.liveTelemetry.collectAsStateWithLifecycle()
    val safetyScore by viewModel.safetyScore.collectAsStateWithLifecycle()
    val bleState by viewModel.bleGlassesState.collectAsStateWithLifecycle()
    val simState by viewModel.simState.collectAsStateWithLifecycle()
    val activeScenario by viewModel.activeScenario.collectAsStateWithLifecycle()
    val alerts by viewModel.alertsList.collectAsStateWithLifecycle()
    val trips by viewModel.tripsList.collectAsStateWithLifecycle()
    val contacts by viewModel.contactsList.collectAsStateWithLifecycle()
    val activeTrip by viewModel.activeTrip.collectAsStateWithLifecycle()
    val sosUiState by viewModel.sosUiState.collectAsStateWithLifecycle()
    val isCameraModeActive by viewModel.isCameraModeActive.collectAsStateWithLifecycle()
    val emergencyConfig by viewModel.emergencySosService.emergencyConfig.collectAsStateWithLifecycle()

    val coroutineScope = rememberCoroutineScope()

    when (rootScreen) {
        RootNavScreen.SPLASH -> {
            SplashScreen(
                onSplashFinished = {
                    rootScreen = if (authState is AuthState.Authenticated) {
                        RootNavScreen.MAIN_APP
                    } else {
                        RootNavScreen.ONBOARDING
                    }
                }
            )
        }

        RootNavScreen.ONBOARDING -> {
            OnboardingScreen(
                onFinishOnboarding = {
                    rootScreen = RootNavScreen.AUTH
                },
                onEnterDemoMode = {
                    viewModel.authRepository.startDemoSession()
                    rootScreen = RootNavScreen.MAIN_APP
                }
            )
        }

        RootNavScreen.AUTH -> {
            if (authState is AuthState.Authenticated) {
                rootScreen = RootNavScreen.MAIN_APP
            } else {
                AuthScreen(
                    authState = authState,
                    onLogin = { email, pass ->
                        coroutineScope.launch {
                            viewModel.authRepository.loginWithEmail(email, pass)
                        }
                    },
                    onRegister = { name, email, pass, vehicle ->
                        coroutineScope.launch {
                            viewModel.authRepository.registerWithEmail(name, email, pass, vehicle)
                        }
                    },
                    onResetPassword = { email ->
                        coroutineScope.launch {
                            viewModel.authRepository.sendPasswordReset(email)
                        }
                    },
                    onEnterDemoMode = {
                        viewModel.authRepository.startDemoSession()
                        rootScreen = RootNavScreen.MAIN_APP
                    }
                )
            }
        }

        RootNavScreen.MAIN_APP -> {
            // Handle Back Button if not on Dashboard tab
            BackHandler(enabled = currentTab != MainAppTab.DASHBOARD) {
                currentTab = MainAppTab.DASHBOARD
            }

            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing),
                containerColor = AutomotiveBackground,
                bottomBar = {
                    NavigationBar(
                        containerColor = AutomotiveSurface,
                        contentColor = CyanAccent,
                        tonalElevation = 8.dp,
                        modifier = Modifier
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .testTag("main_bottom_nav_bar")
                    ) {
                        MainAppTab.values().forEach { tab ->
                            val isSelected = currentTab == tab
                            val iconColor = when {
                                tab == MainAppTab.SOS -> CriticalRed
                                isSelected -> CyanAccent
                                else -> TextMuted
                            }
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title,
                                        tint = iconColor
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.title,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) CyanAccent else TextSecondary
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = if (tab == MainAppTab.SOS) CriticalRed.copy(alpha = 0.2f)
                                    else CyanAccent.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_item_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    when (currentTab) {
                        MainAppTab.DASHBOARD -> {
                            DashboardScreen(
                                telemetry = telemetry,
                                safetyScore = safetyScore,
                                bleState = bleState,
                                activeTrip = activeTrip,
                                recentAlerts = alerts,
                                onNavigateToLiveMonitoring = { currentTab = MainAppTab.SIMULATION },
                                onNavigateToGlassesBle = { currentTab = MainAppTab.GLASSES },
                                onNavigateToEmergencySos = { currentTab = MainAppTab.SOS },
                                onNavigateToTrips = { currentTab = MainAppTab.TRIPS },
                                onStartTrip = { viewModel.startTrip() },
                                onStopTrip = { viewModel.stopTrip() },
                                onAcknowledgeAlert = { alertId -> viewModel.acknowledgeAlert(alertId) }
                            )
                        }

                        MainAppTab.SIMULATION -> {
                            LiveMonitoringScreen(
                                telemetry = telemetry,
                                simState = simState,
                                activeScenario = activeScenario,
                                cameraManager = viewModel.cameraDmsManager,
                                isCameraModeActive = isCameraModeActive,
                                onToggleCameraMode = { active -> viewModel.setCameraModeActive(active) },
                                onStartSimulation = { scenario -> viewModel.startSimulation(scenario) },
                                onPauseSimulation = { viewModel.pauseSimulation() },
                                onResumeSimulation = { viewModel.resumeSimulation() },
                                onStopSimulation = { viewModel.stopSimulation() },
                                onSelectScenario = { scenario -> viewModel.setScenario(scenario) }
                            )
                        }

                        MainAppTab.SOS -> {
                            EmergencySosScreen(
                                sosState = sosUiState,
                                contacts = contacts,
                                onTriggerCountdown = { viewModel.triggerSosCountdown() },
                                onTriggerImmediate = { viewModel.triggerImmediateSos() },
                                onCancelSos = { viewModel.cancelSos() },
                                onDialNumber = { phone -> viewModel.emergencySosService.openDialer(phone) },
                                onSendSms = { phone, msg, id -> viewModel.emergencySosService.openSmsComposer(phone, msg, id) },
                                onDismissSos = { viewModel.dismissSosDialog() },
                                onAddContact = { name, phone, rel, isPri -> viewModel.addEmergencyContact(name, phone, rel, isPri) },
                                onDeleteContact = { id -> viewModel.deleteEmergencyContact(id) }
                            )
                        }

                        MainAppTab.TRIPS -> {
                            TripHistoryScreen(
                                trips = trips,
                                activeTrip = activeTrip,
                                onStartTrip = { viewModel.startTrip() },
                                onStopTrip = { viewModel.stopTrip() }
                            )
                        }

                        MainAppTab.GLASSES -> {
                            GlassesBleScreen(
                                bleState = bleState,
                                onStartScan = { viewModel.startBleScan() },
                                onStopScan = { viewModel.stopBleScan() },
                                onDisconnect = { viewModel.disconnectBle() }
                            )
                        }

                        MainAppTab.PROFILE -> {
                            val profile = (authState as? AuthState.Authenticated)?.profile
                                ?: DriverProfile(
                                    uid = "demo-profile",
                                    fullName = "Alex Vance",
                                    email = "driver@aidrive.ai"
                                )
                            ProfileScreen(
                                profile = profile,
                                onUpdateProfile = { updated -> viewModel.authRepository.updateProfile(updated) },
                                onLogout = {
                                    viewModel.authRepository.logout()
                                    rootScreen = RootNavScreen.AUTH
                                }
                            )
                        }
                    }

                    // Emergency SOS Modal if countdown or preparation is active from anywhere in the app
                    if (currentTab != MainAppTab.SOS) {
                        EmergencySosModal(
                            sosState = sosUiState,
                            onCancel = { viewModel.cancelSos() },
                            onDial = { phone -> viewModel.emergencySosService.openDialer(phone) },
                            onSendSms = { phone, msg, id -> viewModel.emergencySosService.openSmsComposer(phone, msg, id) },
                            onDismiss = { viewModel.dismissSosDialog() }
                        )
                    }
                }
            }
        }
    }
}
