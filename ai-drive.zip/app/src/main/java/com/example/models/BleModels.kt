package com.example.models

import org.json.JSONObject

enum class BleConnectionState {
    DISCONNECTED,
    SCANNING,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    ERROR
}

data class BleGlassesState(
    val connectionState: BleConnectionState = BleConnectionState.DISCONNECTED,
    val deviceName: String = "AI-DRIVE-001",
    val deviceAddress: String? = null,
    val batteryPercent: Int? = null,
    val rssi: Int? = null,
    val firmwareVersion: String = "ESP32-S3-v1.4.2",
    val ov2640CameraOnline: Boolean = false,
    val mpu6050ImuOnline: Boolean = false,
    val mq3AlcoholSensorOnline: Boolean = false,
    val lastHeartbeatMs: Long = 0L,
    val isHardwareConnected: Boolean = false, // Strictly false until physical device streams valid packets
    val statusMessage: String = "Hardware Not Connected"
)

object GlassesBleConstants {
    // Configurable provisional ESP32-S3 GATT UUIDs as specified
    const val DEFAULT_SERVICE_UUID = "12345678-1234-1234-1234-1234567890ab"
    const val TELEMETRY_CHAR_UUID = "12345678-1234-1234-1234-1234567890ac"
    const val DEFAULT_DEVICE_NAME = "AI-DRIVE-001"
    const val DEVICE_NAME_PREFIX = "AI-DRIVE"
}

data class Esp32GlassesJsonPacket(
    val deviceId: String,
    val timestamp: Long,
    val fatigue: String,        // "LOW", "MEDIUM", "HIGH"
    val distraction: String,    // "LOW", "MEDIUM", "HIGH"
    val alcohol: String,        // "UNKNOWN", "NORMAL", "WARNING", "CRITICAL"
    val headMovement: String,   // "NORMAL", "ABNORMAL", "NODDING"
    val riskScore: Int,         // 0..100
    val riskLevel: String       // "SAFE", "WARNING", "CRITICAL"
) {
    companion object {
        fun parseJson(rawString: String): Result<Esp32GlassesJsonPacket> {
            return try {
                val json = JSONObject(rawString)
                val deviceId = json.optString("deviceId", "AI-DRIVE-001")
                val timestamp = json.optLong("timestamp", System.currentTimeMillis() / 1000)
                val fatigue = json.optString("fatigue", "LOW")
                val distraction = json.optString("distraction", "LOW")
                val alcohol = json.optString("alcohol", "UNKNOWN")
                val headMovement = json.optString("headMovement", "NORMAL")
                val riskScore = json.optInt("riskScore", 100)
                val riskLevel = json.optString("riskLevel", "SAFE")

                Result.success(
                    Esp32GlassesJsonPacket(
                        deviceId = deviceId,
                        timestamp = timestamp,
                        fatigue = fatigue,
                        distraction = distraction,
                        alcohol = alcohol,
                        headMovement = headMovement,
                        riskScore = riskScore,
                        riskLevel = riskLevel
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
