package com.example.models

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SosStatus {
    PREPARED,
    DISPATCHED,
    CANCELLED,
    FAILED,
    CONFIRMED
}

@Entity(tableName = "emergency_contacts")
data class EmergencyContact(
    @PrimaryKey
    val id: String,
    val name: String,
    val phone: String,
    val relationship: String,
    val isPrimary: Boolean = false
)

@Entity(tableName = "sos_events")
data class SosEvent(
    @PrimaryKey
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: SosStatus,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val targetPhone: String,
    val messageContent: String,
    val notes: String = ""
)
