package com.example.models

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AlertSeverity {
    INFO,
    WARNING,
    CRITICAL
}

enum class AlertCategory {
    FATIGUE,
    DISTRACTION,
    HEAD_MOVEMENT,
    ALCOHOL,
    SYSTEM
}

@Entity(tableName = "safety_alerts")
data class SafetyAlert(
    @PrimaryKey
    val id: String,
    val title: String,
    val message: String,
    val category: AlertCategory,
    val severity: AlertSeverity,
    val timestamp: Long = System.currentTimeMillis(),
    val acknowledged: Boolean = false,
    val isDemo: Boolean = true
)
