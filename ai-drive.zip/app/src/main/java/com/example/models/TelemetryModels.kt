package com.example.models

enum class DrowsinessLevel {
    ALERT,
    MILD_FATIGUE,
    SEVERE_FATIGUE
}

enum class DistractionType {
    NONE,
    PHONE_LOOKDOWN,
    GAZE_LEFT,
    GAZE_RIGHT,
    EYES_OFF_ROAD
}

enum class AlcoholState {
    SENSOR_WARMING_UP,
    CLEAR,
    TRACE,
    WARNING,
    DANGER
}

enum class DataSource {
    SIMULATED_DEMO,
    ESP32_S3_BLE,
    MANUAL_INJECTION
}

enum class SafetyStatus {
    OPTIMAL,
    SAFE,
    CAUTION,
    CRITICAL
}

data class TelemetryData(
    val eyeClosurePerclos: Float = 6.5f, // Percentage 0..100
    val blinkDurationMs: Long = 180L,
    val drowsinessLevel: DrowsinessLevel = DrowsinessLevel.ALERT,
    val gazeOffRoadSeconds: Float = 0.2f,
    val distractionType: DistractionType = DistractionType.NONE,
    val pitchDeg: Float = 1.2f, // Head tilt forward/backward
    val rollDeg: Float = -0.5f, // Head tilt side
    val yawDeg: Float = 0.8f,  // Head look angle
    val headNoddingDetected: Boolean = false,
    val alcoholMgL: Float = 0.00f, // MQ-3 sensor output
    val alcoholState: AlcoholState = AlcoholState.CLEAR,
    val timestamp: Long = System.currentTimeMillis(),
    val source: DataSource = DataSource.SIMULATED_DEMO,
    val isStale: Boolean = false
)

data class SafetyScore(
    val score: Int = 98,
    val fatiguePenalty: Int = 0,
    val distractionPenalty: Int = 0,
    val headMovementPenalty: Int = 0,
    val alcoholPenalty: Int = 0,
    val status: SafetyStatus = SafetyStatus.OPTIMAL
)

enum class SimulationScenario(val displayName: String, val description: String) {
    NORMAL_DRIVING(
        displayName = "Normal Driving",
        description = "Driver is attentive, steady posture, clear alcohol reading."
    ),
    FATIGUE_WARNING(
        displayName = "Fatigue & Micro-sleep",
        description = "Prolonged eye closure (PERCLOS > 40%), slow blinks, drowsiness alert."
    ),
    DISTRACTION_WARNING(
        displayName = "Phone & Off-road Gaze",
        description = "Gaze diverted away from roadway for > 2.5s, mobile phone lookdown."
    ),
    ABNORMAL_HEAD_MOVEMENT(
        displayName = "Abnormal Head Drop",
        description = "Sudden nodding / head bobbing detected by MPU6050 gyroscope."
    ),
    ALCOHOL_WARNING(
        displayName = "MQ-3 Alcohol Anomaly",
        description = "Experimental alcohol vapor spike above legal limit (0.09 mg/L)."
    ),
    MULTIPLE_RISK(
        displayName = "Compound Multi-Risk",
        description = "Concurrent severe fatigue, distracted gaze, and erratic head posture."
    )
}
