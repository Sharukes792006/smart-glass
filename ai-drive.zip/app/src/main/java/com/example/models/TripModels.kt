package com.example.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class Trip(
    @PrimaryKey
    val id: String,
    val startTime: Long,
    val endTime: Long? = null,
    val durationSeconds: Long = 0L,
    val distanceKm: Float = 0f,
    val averageSpeedKmh: Float = 0f,
    val safetyScore: Int = 95,
    val fatigueEventsCount: Int = 0,
    val distractionEventsCount: Int = 0,
    val alcoholAnomaliesCount: Int = 0,
    val isLive: Boolean = false,
    val isSimulated: Boolean = true,
    val originSummary: String = "Current Location",
    val destinationSummary: String = "Destination"
)
