package com.example.models

data class EmergencyConfig(
    val autoAssistanceEnabled: Boolean = false,
    val userConsentGranted: Boolean = false,
    val countdownDurationSeconds: Int = 10,
    val includeGpsLocation: Boolean = true,
    val smsTemplate: String = "EMERGENCY ALERT: AI Drive Smart Glasses detected sustained critical driver distress. Please verify driver safety immediately.",
    val isTestSimulationMode: Boolean = true // Safe default so development never accidentally calls/texts
)

enum class ActionDeliveryStatus {
    IDLE,
    PENDING,
    SENDING,
    SENT_DIRECT,          // Successfully submitted via SmsManager
    INITIATED_CALL,       // ACTION_CALL invoked
    FALLBACK_COMPOSER,    // User opened SMS Composer fallback
    FALLBACK_DIALER,      // User opened phone dialer fallback
    FAILED,
    SIMULATED_SUCCESS,    // Tested in simulation mode without real transmission
    CANCELLED
}

data class ContactEmergencyProgress(
    val contact: EmergencyContact,
    val smsStatus: ActionDeliveryStatus = ActionDeliveryStatus.IDLE,
    val callStatus: ActionDeliveryStatus = ActionDeliveryStatus.IDLE,
    val errorDetails: String? = null
)
