package com.example.models

data class DriverProfile(
    val uid: String,
    val fullName: String,
    val email: String,
    val vehicleModel: String = "Tesla Model 3 / CyberTruck",
    val bloodGroup: String = "O+",
    val driverLicense: String = "DL-2024-8849",
    val isDemoAccount: Boolean = true,
    val glassesPairedName: String = "AI-Drive-ESP32S3-Glass"
)
