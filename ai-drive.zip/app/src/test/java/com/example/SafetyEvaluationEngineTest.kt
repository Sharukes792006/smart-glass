package com.example

import com.example.models.AlertCategory
import com.example.models.AlertSeverity
import com.example.models.DataSource
import com.example.models.DistractionType
import com.example.models.DrowsinessLevel
import com.example.models.SafetyStatus
import com.example.models.TelemetryData
import com.example.services.SafetyEvaluationEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SafetyEvaluationEngineTest {

    @Test
    fun `baseline telemetry yields optimal safety score`() {
        val normalTelemetry = TelemetryData(
            eyeClosurePerclos = 5.0f,
            drowsinessLevel = DrowsinessLevel.ALERT,
            gazeOffRoadSeconds = 0.2f,
            distractionType = DistractionType.NONE,
            pitchDeg = 1.0f,
            headNoddingDetected = false,
            alcoholMgL = 0.00f
        )

        val score = SafetyEvaluationEngine.calculateSafetyScore(normalTelemetry)

        assertEquals(100, score.score)
        assertEquals(0, score.fatiguePenalty)
        assertEquals(0, score.distractionPenalty)
        assertEquals(0, score.headMovementPenalty)
        assertEquals(0, score.alcoholPenalty)
        assertEquals(SafetyStatus.OPTIMAL, score.status)
    }

    @Test
    fun `severe fatigue triggers penalty and critical alert`() {
        val drowsyTelemetry = TelemetryData(
            eyeClosurePerclos = 48.0f,
            drowsinessLevel = DrowsinessLevel.SEVERE_FATIGUE,
            source = DataSource.SIMULATED_DEMO
        )

        val score = SafetyEvaluationEngine.calculateSafetyScore(drowsyTelemetry)
        assertTrue(score.fatiguePenalty >= 35)
        assertTrue(score.score <= 65)

        val alert = SafetyEvaluationEngine.detectAlert(drowsyTelemetry)
        assertNotNull(alert)
        assertEquals(AlertCategory.FATIGUE, alert!!.category)
        assertEquals(AlertSeverity.CRITICAL, alert.severity)
    }

    @Test
    fun `alcohol exceeding threshold triggers critical alert`() {
        val alcoholTelemetry = TelemetryData(
            alcoholMgL = 0.09f,
            source = DataSource.SIMULATED_DEMO
        )

        val score = SafetyEvaluationEngine.calculateSafetyScore(alcoholTelemetry)
        assertEquals(45, score.alcoholPenalty)

        val alert = SafetyEvaluationEngine.detectAlert(alcoholTelemetry)
        assertNotNull(alert)
        assertEquals(AlertCategory.ALCOHOL, alert!!.category)
        assertEquals(AlertSeverity.CRITICAL, alert.severity)
    }

    @Test
    fun `abnormal head nodding triggers head penalty`() {
        val nodTelemetry = TelemetryData(
            headNoddingDetected = true,
            pitchDeg = -32.0f
        )

        val score = SafetyEvaluationEngine.calculateSafetyScore(nodTelemetry)
        assertEquals(25, score.headMovementPenalty)

        val alert = SafetyEvaluationEngine.detectAlert(nodTelemetry)
        assertNotNull(alert)
        assertEquals(AlertCategory.HEAD_MOVEMENT, alert!!.category)
    }
}
