package com.example

import com.example.models.DrowsinessLevel
import com.example.services.camera.DriverFatigueAnalyzer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class DriverFatigueAnalyzerTest {

    @Test
    fun `initial camera telemetry is idle with alert state`() {
        val analyzer = DriverFatigueAnalyzer()
        val initialTelemetry = analyzer.dmsTelemetry.value

        assertNotNull(initialTelemetry)
        assertEquals(DrowsinessLevel.ALERT, initialTelemetry.drowsinessLevel)
        assertEquals(0f, initialTelemetry.eyeClosurePerclos, 0.01f)
    }

    @Test
    fun `analyzer callback receives processed telemetry`() {
        var callbackInvoked = false
        val analyzer = DriverFatigueAnalyzer {
            callbackInvoked = true
        }

        assertNotNull(analyzer)
    }
}
