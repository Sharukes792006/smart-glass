package com.example

import com.example.models.DataSource
import com.example.models.SimulationScenario
import com.example.services.SimulationEngine
import com.example.services.SimulationState
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SimulationEngineTest {

    private val testDispatcher = StandardTestDispatcher()
    private val testScope = TestScope(testDispatcher)

    @Test
    fun `simulation engine lifecycle starts pauses resumes and stops`() = testScope.runTest {
        val engine = SimulationEngine(this)

        assertEquals(SimulationState.STOPPED, engine.simState.value)

        engine.start(SimulationScenario.NORMAL_DRIVING)
        assertEquals(SimulationState.RUNNING, engine.simState.value)

        advanceTimeBy(900)
        assertEquals(DataSource.SIMULATED_DEMO, engine.telemetry.value.source)
        assertFalse(engine.telemetry.value.isStale)

        engine.pause()
        assertEquals(SimulationState.PAUSED, engine.simState.value)
        assertTrue(engine.telemetry.value.isStale)

        engine.resume()
        assertEquals(SimulationState.RUNNING, engine.simState.value)
        assertFalse(engine.telemetry.value.isStale)

        engine.stop()
        assertEquals(SimulationState.STOPPED, engine.simState.value)
    }

    @Test
    fun `switching to fatigue scenario generates elevated perclos`() = testScope.runTest {
        val engine = SimulationEngine(this)
        engine.start(SimulationScenario.FATIGUE_WARNING)

        advanceTimeBy(1000)
        assertTrue(engine.telemetry.value.eyeClosurePerclos > 25.0f)

        engine.stop()
    }
}
